import { useEffect, useState } from 'react';

import {
  PcControl,
  type ExecuteEnsuredSshCommandResult,
  type OpenVpnProfile,
  type OpenVpnStatusResult,
  type TrustedSshHostKeyResult,
} from '@pc-control/capacitor-pc-control';
import type { PcControlConfig } from '@pc-control/core';

interface Phase2NetworkPanelProps {
  config: PcControlConfig;
  onOutput: (output: string) => void;
}

type NetworkAction =
  | 'check-router'
  | 'refresh-profiles'
  | 'connect'
  | 'disconnect'
  | 'ensure'
  | 'windows'
  | 'router'
  | 'permission';

const DEFAULT_VPN_STATUS: OpenVpnStatusResult = {
  status: 'disconnected',
  vpnWasStartedByApp: false,
};

function describeError(error: unknown): string {
  if (typeof error === 'object' && error !== null) {
    const candidate = error as { code?: unknown; message?: unknown };
    const message = typeof candidate.message === 'string' ? candidate.message : '알 수 없는 오류';
    return typeof candidate.code === 'string' ? `[${candidate.code}] ${message}` : message;
  }
  return '알 수 없는 오류';
}

function trustedFingerprint(key: TrustedSshHostKeyResult | undefined): string | undefined {
  return key?.trusted ? key.fingerprint : undefined;
}

function formatEnsuredResult(
  label: string,
  command: string,
  result: ExecuteEnsuredSshCommandResult,
): string {
  const stdout = result.stdout.trimEnd() || '(stdout 없음)';
  const stderr = result.stderr.trimEnd();
  return [
    `${label} > ${command}`,
    `network: ${result.networkPath}`,
    `exit ${result.exitCode}`,
    stdout,
    ...(stderr ? [`stderr: ${stderr}`] : []),
  ].join('\n');
}

export function Phase2NetworkPanel({ config, onOutput }: Phase2NetworkPanelProps) {
  const [installed, setInstalled] = useState<boolean>();
  const [profiles, setProfiles] = useState<OpenVpnProfile[]>([]);
  const [selectedProfileId, setSelectedProfileId] = useState<string>();
  const [vpnStatus, setVpnStatus] = useState<OpenVpnStatusResult>(DEFAULT_VPN_STATUS);
  const [routerReachability, setRouterReachability] = useState('아직 확인하지 않음');
  const [result, setResult] = useState('아직 실행하지 않음');
  const [busyAction, setBusyAction] = useState<NetworkAction>();
  const [routerUsername, setRouterUsername] = useState('');
  const [disconnectAfterAction, setDisconnectAfterAction] = useState(false);
  const [windowsHostKey, setWindowsHostKey] = useState<TrustedSshHostKeyResult>();
  const [routerHostKey, setRouterHostKey] = useState<TrustedSshHostKeyResult>();

  const homeNetworkOptions = {
    routerHost: config.router.host,
    routerPort: config.router.sshPort,
  } as const;

  async function refreshStatus() {
    const [installation, status, windowsKey, routerKey] = await Promise.all([
      PcControl.isOpenVpnInstalled(),
      PcControl.getOpenVpnStatus(),
      PcControl.getTrustedSshHostKey({ host: config.pc.host, port: config.pc.sshPort }),
      PcControl.getTrustedSshHostKey({ host: config.router.host, port: config.router.sshPort }),
    ]);
    setInstalled(installation.installed);
    setVpnStatus(status);
    setWindowsHostKey(windowsKey);
    setRouterHostKey(routerKey);
  }

  useEffect(() => {
    let active = true;
    async function loadInitialStatus() {
      try {
        const [installation, status, windowsKey, routerKey] = await Promise.all([
          PcControl.isOpenVpnInstalled(),
          PcControl.getOpenVpnStatus(),
          PcControl.getTrustedSshHostKey({ host: config.pc.host, port: config.pc.sshPort }),
          PcControl.getTrustedSshHostKey({ host: config.router.host, port: config.router.sshPort }),
        ]);
        if (!active) return;
        setInstalled(installation.installed);
        setVpnStatus(status);
        setWindowsHostKey(windowsKey);
        setRouterHostKey(routerKey);
      } catch (error) {
        if (active) setResult(describeError(error));
      }
    }
    void loadInitialStatus();
    return () => {
      active = false;
    };
  }, [config.pc.host, config.pc.sshPort, config.router.host, config.router.sshPort]);

  async function runAction(action: NetworkAction, operation: () => Promise<void>) {
    setBusyAction(action);
    try {
      await operation();
    } catch (error) {
      setResult(describeError(error));
    } finally {
      setBusyAction(undefined);
    }
  }

  function refreshProfiles() {
    return runAction('refresh-profiles', async () => {
      const response = await PcControl.getOpenVpnProfiles();
      setProfiles(response.profiles);
      setSelectedProfileId(response.selectedProfileId);
      setResult(
        response.profiles.length
          ? 'OpenVPN 프로필을 불러왔습니다.'
          : '등록된 OpenVPN 프로필이 없습니다.',
      );
      await refreshStatus();
    });
  }

  function selectProfile(profileId: string) {
    return runAction('refresh-profiles', async () => {
      const response = await PcControl.selectOpenVpnProfile({ profileId });
      setProfiles(response.profiles);
      setSelectedProfileId(response.selectedProfileId);
      setResult('OpenVPN 프로필을 선택했습니다.');
    });
  }

  function checkRouter() {
    return runAction('check-router', async () => {
      const response = await PcControl.checkHost({
        host: config.router.host,
        port: config.router.sshPort,
        timeoutMs: 2_000,
      });
      const detail = response.reachable
        ? `reachable${response.latencyMs === undefined ? '' : ` (${response.latencyMs}ms)`}`
        : 'unreachable';
      setRouterReachability(detail);
      setResult(`Router ${detail}`);
    });
  }

  function ensureHomeNetwork() {
    return runAction('ensure', async () => {
      const response = await PcControl.ensureHomeNetwork(homeNetworkOptions);
      setResult(`Home Network 준비 완료: ${response.path}`);
      await refreshStatus();
    });
  }

  function runEnsuredSsh(
    action: 'windows' | 'router',
    target: 'windows' | 'router',
    command: string,
    username: string,
    fingerprint: string | undefined,
  ) {
    if (!fingerprint) {
      setResult('Phase 1에서 해당 서버의 호스트 키 지문을 먼저 신뢰해야 합니다.');
      return;
    }
    if (!username.trim()) {
      setResult('공유기 SSH 사용자 이름을 입력하세요.');
      return;
    }
    const targetConfig = target === 'windows' ? config.pc : config.router;
    return runAction(action, async () => {
      const response = await PcControl.executeEnsuredSshCommand({
        ...homeNetworkOptions,
        command,
        commandTimeoutMs: 8_000,
        connectTimeoutMs: 8_000,
        expectedHostFingerprint: fingerprint,
        host: targetConfig.host,
        port: targetConfig.sshPort,
        target,
        username: username.trim(),
      });
      onOutput(
        formatEnsuredResult(target === 'windows' ? 'Windows PC' : 'Router', command, response),
      );
      setResult(`${response.networkPath} 경로에서 ${command} 성공`);
      if (disconnectAfterAction && response.vpnWasStartedByApp) {
        await PcControl.disconnectOpenVpn({ onlyIfStartedByApp: true });
        setResult(`${response.networkPath} 경로에서 ${command} 성공 후 앱 VPN을 해제했습니다.`);
      }
      await refreshStatus();
    });
  }

  const busy = busyAction !== undefined;

  return (
    <section className="mt-8 border-t border-slate-200 py-6">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">Phase 2</p>
      <h2 className="mt-2 text-lg font-semibold">Network test</h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">
        Router reachability를 먼저 확인하고, 필요할 때만 OpenVPN for Android를 연결합니다.
      </p>

      <div className="mt-4 text-sm text-slate-700">
        <div>
          Router:{' '}
          <span className="font-mono">
            {config.router.host}:{config.router.sshPort}
          </span>
        </div>
        <div className="mt-1">Reachability: {routerReachability}</div>
        <button
          className="mt-3 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium disabled:opacity-50"
          disabled={busy}
          onClick={() => void checkRouter()}
          type="button"
        >
          {busyAction === 'check-router' ? '확인 중…' : 'Router Check'}
        </button>
      </div>

      <div className="mt-6 border-t border-slate-200 pt-5 text-sm text-slate-700">
        <h3 className="font-semibold">OpenVPN for Android</h3>
        <p className="mt-2">
          Installed: {installed === undefined ? '확인 중…' : installed ? 'yes' : 'no'}
        </p>
        <p className="mt-1">
          State: {vpnStatus.status}
          {vpnStatus.profileId ? ` (${vpnStatus.profileId})` : ''}
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium disabled:opacity-50"
            disabled={busy || installed === false}
            onClick={() =>
              void runAction('permission', async () => {
                await PcControl.prepareOpenVpnControl();
                setResult('OpenVPN 외부 제어 권한을 확인했습니다.');
                await refreshStatus();
              })
            }
            type="button"
          >
            {busyAction === 'permission' ? '권한 확인 중…' : '권한 확인'}
          </button>
          <button
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium disabled:opacity-50"
            disabled={busy || installed === false}
            onClick={() => void refreshProfiles()}
            type="button"
          >
            {busyAction === 'refresh-profiles' ? '불러오는 중…' : 'Refresh Profiles'}
          </button>
          <button
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium disabled:opacity-50"
            disabled={busy || !selectedProfileId}
            onClick={() =>
              void runAction('connect', async () => {
                const response = await PcControl.connectOpenVpn({ profileId: selectedProfileId! });
                setVpnStatus(response);
                setResult('OpenVPN 연결 완료 callback을 확인했습니다.');
              })
            }
            type="button"
          >
            {busyAction === 'connect' ? '연결 중…' : 'Connect'}
          </button>
          <button
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium disabled:opacity-50"
            disabled={busy || vpnStatus.status === 'disconnected'}
            onClick={() =>
              void runAction('disconnect', async () => {
                const response = await PcControl.disconnectOpenVpn();
                setVpnStatus(response);
                setResult('OpenVPN 연결을 해제했습니다.');
              })
            }
            type="button"
          >
            {busyAction === 'disconnect' ? '해제 중…' : 'Disconnect'}
          </button>
        </div>

        <label className="mt-4 block text-sm">
          Profile
          <select
            className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-950 disabled:opacity-50"
            disabled={busy || profiles.length === 0}
            onChange={(event) => void selectProfile(event.target.value)}
            value={selectedProfileId ?? ''}
          >
            <option disabled value="">
              프로필 선택
            </option>
            {profiles.map((profile) => (
              <option key={profile.id} value={profile.id}>
                {profile.name}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="mt-6 border-t border-slate-200 pt-5 text-sm text-slate-700">
        <h3 className="font-semibold">Home Network</h3>
        <button
          className="mt-3 rounded-md bg-slate-950 px-3 py-2 text-sm font-medium text-white disabled:bg-slate-400"
          disabled={busy}
          onClick={() => void ensureHomeNetwork()}
          type="button"
        >
          {busyAction === 'ensure' ? '준비 중…' : 'Ensure Home Network'}
        </button>
        <label className="mt-4 flex items-center gap-2">
          <input
            checked={disconnectAfterAction}
            onChange={(event) => setDisconnectAfterAction(event.target.checked)}
            type="checkbox"
          />
          작업 후 앱이 연결한 VPN 자동 해제
        </label>
      </div>

      <div className="mt-6 border-t border-slate-200 pt-5 text-sm text-slate-700">
        <h3 className="font-semibold">SSH via ensured network</h3>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            className="rounded-md bg-slate-950 px-3 py-2 text-sm font-medium text-white disabled:bg-slate-400"
            disabled={busy || !trustedFingerprint(windowsHostKey)}
            onClick={() =>
              void runEnsuredSsh(
                'windows',
                'windows',
                'hostname',
                config.pc.sshUser,
                trustedFingerprint(windowsHostKey),
              )
            }
            type="button"
          >
            {busyAction === 'windows' ? '실행 중…' : 'Windows hostname'}
          </button>
        </div>
        <label className="mt-4 block">
          공유기 SSH 사용자
          <input
            autoCapitalize="none"
            className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-950"
            onChange={(event) => setRouterUsername(event.target.value)}
            placeholder="사용자 이름"
            spellCheck={false}
            value={routerUsername}
          />
        </label>
        <button
          className="mt-3 rounded-md bg-slate-950 px-3 py-2 text-sm font-medium text-white disabled:bg-slate-400"
          disabled={busy || !trustedFingerprint(routerHostKey)}
          onClick={() =>
            void runEnsuredSsh(
              'router',
              'router',
              'uname -n',
              routerUsername,
              trustedFingerprint(routerHostKey),
            )
          }
          type="button"
        >
          {busyAction === 'router' ? '실행 중…' : 'Router uname -n'}
        </button>
      </div>

      <p aria-live="polite" className="mt-5 text-sm leading-5 text-slate-600">
        {result}
      </p>
    </section>
  );
}
