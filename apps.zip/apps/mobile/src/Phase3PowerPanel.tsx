import { useEffect, useState } from 'react';

import {
  PcControl,
  type PowerActionResult,
  type TrustedSshHostKeyResult,
} from '@pc-control/capacitor-pc-control';
import type { PcControlConfig, PcStatus, PowerAction } from '@pc-control/core';

interface Phase3PowerPanelProps {
  config: PcControlConfig;
}

type PowerBusy = PowerAction | 'status' | undefined;

const POWER_STATUS_LABEL: Record<PcStatus, string> = {
  unknown: 'Unknown',
  online: 'Online',
  offline: 'Offline',
  waking: 'Waking…',
  'shutting-down': 'Shutting down…',
  rebooting: 'Rebooting…',
  error: 'Error',
};

function describeError(error: unknown): string {
  if (typeof error === 'object' && error !== null) {
    const candidate = error as { code?: unknown; message?: unknown };
    const message = typeof candidate.message === 'string' ? candidate.message : '알 수 없는 오류';
    return typeof candidate.code === 'string' ? `[${candidate.code}] ${message}` : message;
  }
  return '알 수 없는 오류';
}

function statusColor(status: PcStatus): string {
  switch (status) {
    case 'online':
      return 'text-emerald-700';
    case 'offline':
      return 'text-slate-500';
    case 'unknown':
      return 'text-slate-400';
    case 'waking':
    case 'shutting-down':
    case 'rebooting':
      return 'text-amber-700';
    case 'error':
      return 'text-red-700';
    default:
      return 'text-slate-600';
  }
}

export function Phase3PowerPanel({ config }: Phase3PowerPanelProps) {
  const [pcStatus, setPcStatus] = useState<PcStatus>('unknown');
  const [pcReachable, setPcReachable] = useState<boolean>();
  const [pcLatency, setPcLatency] = useState<number>();
  const [statusMessage, setStatusMessage] = useState('아직 확인하지 않음');
  const [lastResult, setLastResult] = useState<PowerActionResult>();
  const [lastError, setLastError] = useState<string>();
  const [busy, setBusy] = useState<PowerBusy>(undefined);
  const [autoDisconnect, setAutoDisconnect] = useState(false);
  const [confirmAction, setConfirmAction] = useState<PowerAction>();
  const [pcHostKey, setPcHostKey] = useState<TrustedSshHostKeyResult>();
  const [routerHostKey, setRouterHostKey] = useState<TrustedSshHostKeyResult>();
  const [routerUsername, setRouterUsername] = useState(config.router.sshUser ?? '');

  const isBusy = busy !== undefined;

  async function refreshTrustedKeys() {
    const [pcKey, routerKey] = await Promise.all([
      PcControl.getTrustedSshHostKey({ host: config.pc.host, port: config.pc.sshPort }),
      PcControl.getTrustedSshHostKey({ host: config.router.host, port: config.router.sshPort }),
    ]);
    setPcHostKey(pcKey);
    setRouterHostKey(routerKey);
  }

  async function checkPcStatus() {
    setBusy('status');
    setStatusMessage('PC 상태 확인 중…');
    try {
      const result = await PcControl.getPcStatus({
        host: config.pc.host,
        port: config.pc.sshPort,
        timeoutMs: 2_500,
        routerHost: config.router.host,
        routerPort: config.router.sshPort,
        routerTimeoutMs: 2_000,
      });
      setPcStatus(result.status);
      setPcReachable(result.reachable);
      setPcLatency(result.latencyMs);
      if (result.status === 'unknown') {
        setStatusMessage('Unknown — Home Network에 접근할 수 없어 상태를 알 수 없음 (LTE/VPN OFF)');
      } else {
        setStatusMessage(result.reachable ? `Online (${result.latencyMs ?? '-'}ms)` : 'Offline');
      }
    } catch (error) {
      setPcStatus('error');
      setStatusMessage(describeError(error));
    } finally {
      setBusy(undefined);
    }
  }

  // Initial load: sync external native state into React after mount
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial sync from native layer
    void refreshTrustedKeys();
    void checkPcStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config.pc.host, config.pc.sshPort, config.router.host, config.router.sshPort]);

  async function runAction(action: PowerAction) {
    // Guard: require trusted host keys for relevant target
    if (action === 'power-on' && !routerHostKey?.trusted) {
      setLastError('공유기 서버의 호스트 키를 먼저 신뢰해야 합니다.');
      return;
    }
    if (action === 'power-on' && !routerUsername.trim()) {
      setLastError('Power On을 실행하려면 공유기 SSH 사용자 이름이 필요합니다.');
      return;
    }
    if ((action === 'shutdown' || action === 'reboot') && !pcHostKey?.trusted) {
      setLastError('Phase 1에서 Windows host key를 먼저 신뢰해야 합니다.');
      return;
    }

    setBusy(action);
    setLastError(undefined);
    const busyLabel =
      action === 'power-on' ? 'Waking…' : action === 'shutdown' ? 'Shutting down…' : 'Rebooting…';
    setPcStatus(
      action === 'power-on' ? 'waking' : action === 'shutdown' ? 'shutting-down' : 'rebooting',
    );
    setStatusMessage(busyLabel);

    try {
      const result = await PcControl.runPowerAction({
        action,
        autoDisconnectVpn: autoDisconnect,
        macAddress: config.pc.macAddress,
        pcHost: config.pc.host,
        ...(pcHostKey?.fingerprint ? { pcHostFingerprint: pcHostKey.fingerprint } : {}),
        pcPort: config.pc.sshPort,
        pcUsername: config.pc.sshUser,
        routerHost: config.router.host,
        ...(routerHostKey?.fingerprint ? { routerHostFingerprint: routerHostKey.fingerprint } : {}),
        routerPort: config.router.sshPort,
        routerUsername: routerUsername.trim(),
        wolInterface: config.router.wolInterface,
      });
      setLastResult(result);
      setPcStatus(result.finalStatus as PcStatus);
      setPcReachable(result.finalStatus === 'online');
      setStatusMessage(
        result.commandExecuted
          ? `${action} 성공 (${(result.durationMs / 1000).toFixed(1)}s) via ${result.networkPath}`
          : `${action} 이미 ${result.finalStatus} 상태`,
      );
    } catch (error) {
      const message = describeError(error);
      setLastError(message);
      setStatusMessage(message);
      setPcStatus('error');
    } finally {
      setBusy(undefined);
      setConfirmAction(undefined);
      void refreshTrustedKeys();
    }
  }

  function requestAction(action: PowerAction) {
    if (action === 'shutdown' || action === 'reboot') {
      if (confirmAction !== action) {
        setConfirmAction(action);
        return;
      }
    }
    void runAction(action);
  }

  return (
    <section className="mt-8 border-t border-slate-200 py-6">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">Phase 3</p>
      <h2 className="mt-2 text-lg font-semibold">PC Power Control</h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">
        실제 전원 제어는 고정된 native 명령으로만 실행되며, 완료까지 PC 상태 전환을 확인합니다.
      </p>

      <div className="mt-4 rounded-md border border-slate-200 bg-white p-4">
        <div className="flex items-baseline justify-between gap-3">
          <span className="text-sm font-medium text-slate-700">PC Status</span>
          <span className="font-mono text-xs text-slate-500">
            {config.pc.host}:{config.pc.sshPort}
          </span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <span className={`text-sm font-semibold ${statusColor(pcStatus)}`}>
            ● {POWER_STATUS_LABEL[pcStatus] ?? pcStatus}
          </span>
          {pcReachable !== undefined ? (
            <span className="text-xs text-slate-500">
              {pcReachable ? `reachable${pcLatency ? ` ${pcLatency}ms` : ''}` : 'unreachable'}
            </span>
          ) : null}
        </div>
        <p aria-live="polite" className="mt-2 text-sm leading-5 text-slate-600">
          {statusMessage}
        </p>
        <button
          className="mt-3 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm font-medium disabled:opacity-50"
          disabled={isBusy}
          onClick={() => void checkPcStatus()}
          type="button"
        >
          {busy === 'status' ? '확인 중…' : 'PC 상태 확인'}
        </button>
      </div>

      <label className="block text-sm text-slate-700">
        공유기 SSH 사용자 (Power On 시 필요)
        <input
          autoCapitalize="none"
          className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-slate-950"
          onChange={(event) => setRouterUsername(event.target.value)}
          placeholder="예: router-user"
          spellCheck={false}
          value={routerUsername}
        />
      </label>

      <div className="mt-5 flex flex-col gap-2">
        <button
          className="rounded-md bg-slate-950 px-4 py-3 text-sm font-semibold text-white disabled:bg-slate-400"
          disabled={isBusy}
          onClick={() => void requestAction('power-on')}
          type="button"
        >
          {busy === 'power-on' ? 'Waking…' : 'Power On'}
        </button>

        <div className="flex gap-2">
          <button
            className="flex-1 rounded-md bg-amber-700 px-4 py-3 text-sm font-semibold text-white disabled:bg-slate-400"
            disabled={isBusy}
            onClick={() => void requestAction('shutdown')}
            type="button"
          >
            {busy === 'shutdown'
              ? 'Shutting down…'
              : confirmAction === 'shutdown'
                ? 'Shutdown 확인 (다시 클릭)'
                : 'Shutdown'}
          </button>
          <button
            className="flex-1 rounded-md bg-slate-800 px-4 py-3 text-sm font-semibold text-white disabled:bg-slate-400"
            disabled={isBusy}
            onClick={() => void requestAction('reboot')}
            type="button"
          >
            {busy === 'reboot'
              ? 'Rebooting…'
              : confirmAction === 'reboot'
                ? 'Reboot 확인 (다시 클릭)'
                : 'Reboot'}
          </button>
        </div>
        {confirmAction ? (
          <button
            className="text-xs text-slate-500 underline"
            onClick={() => setConfirmAction(undefined)}
            type="button"
          >
            취소
          </button>
        ) : null}
      </div>

      <label className="mt-4 flex items-center gap-2 text-sm text-slate-700">
        <input
          checked={autoDisconnect}
          onChange={(event) => setAutoDisconnect(event.target.checked)}
          type="checkbox"
        />
        작업 후 앱이 연결한 VPN 자동 해제
      </label>

      {(lastResult || lastError) && (
        <div className="mt-4 rounded-md border border-slate-200 bg-slate-50 p-4">
          <h3 className="text-sm font-semibold text-slate-800">Last Action</h3>
          {lastResult ? (
            <div className="mt-2 font-mono text-xs leading-5 text-slate-700">
              <div>action: {lastResult.action}</div>
              <div>
                {lastResult.previousStatus} → {lastResult.finalStatus}
              </div>
              <div>network: {lastResult.networkPath}</div>
              <div>vpnStartedByApp: {String(lastResult.vpnWasStartedByApp)}</div>
              <div>commandExecuted: {String(lastResult.commandExecuted)}</div>
              <div>duration: {(lastResult.durationMs / 1000).toFixed(1)}s</div>
            </div>
          ) : null}
          {lastError ? <p className="mt-2 text-sm leading-5 text-red-700">{lastError}</p> : null}
        </div>
      )}

      <p className="mt-3 text-xs leading-5 text-slate-500">
        Power On은 설정한 공유기에서 WOL을 실행하고, Shutdown/Reboot는 설정한 Windows PC에서 고정
        명령만 사용합니다. 진행 중인 작업이 끝나기 전에는 다른 버튼을 누를 수 없습니다.
      </p>
    </section>
  );
}
