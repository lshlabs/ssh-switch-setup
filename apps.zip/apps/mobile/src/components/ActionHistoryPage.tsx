import { useEffect, useState } from 'react';
import { ArrowLeft, Check, History } from 'lucide-react';
import type { PowerActionHistoryItem } from '../hooks/useHomeSession';
import {
  ACTION_ICON,
  ACTION_LABEL_KEY,
  actionHistoryDescriptionKey,
  actionHistoryOutcomeKey,
  actionHistoryTone,
} from '../lib/actionHistory';
import { useAppCopy } from '../i18n';
import type { Translate } from '../i18n';

type BackHandler = () => boolean;

export function ActionHistoryPage({
  history,
  onBack,
  registerBack,
}: {
  history: PowerActionHistoryItem[];
  onBack: () => void;
  registerBack: (handler: BackHandler | null) => void;
}) {
  const { t, locale } = useAppCopy();
  const [relativeNow, setRelativeNow] = useState(Date.now);

  useEffect(() => {
    const timer = window.setInterval(() => setRelativeNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    registerBack(() => {
      onBack();
      return true;
    });
    return () => registerBack(null);
  }, [onBack, registerBack]);

  return (
    <div className="action-history-page">
      <div className="settings-detail-top action-history-page-top">
        <button
          type="button"
          className="page-back"
          aria-label={t('navigation.backToHome')}
          onClick={onBack}
        >
          <ArrowLeft size={22} aria-hidden="true" />
        </button>
        <h1 className="settings-title">{t('history.title')}</h1>
      </div>

      {history.length ? (
        <ActionHistoryList history={history} relativeNow={relativeNow} t={t} locale={locale} />
      ) : (
        <section className="action-history-empty" aria-live="polite">
          <History size={28} aria-hidden="true" />
          <h2>{t('history.emptyTitle')}</h2>
          <p>{t('history.emptyDescription')}</p>
        </section>
      )}
    </div>
  );
}

function ActionHistoryList({
  history,
  relativeNow,
  t,
  locale,
}: {
  history: PowerActionHistoryItem[];
  relativeNow: number;
  t: Translate;
  locale: string;
}) {
  return (
    <ol className="action-history-page-list">
      {history.map((item) => {
        const Icon = ACTION_ICON[item.action];
        const tone = actionHistoryTone(item.action, item.finalStatus);
        const outcomeKey = actionHistoryOutcomeKey(item.finalStatus);
        const outcomeTone =
          item.finalStatus === 'error'
            ? 'error'
            : item.finalStatus === 'online' || item.finalStatus === 'offline'
              ? 'complete'
              : 'pending';

        return (
          <li className="action-history-page-item" key={item.id}>
            <span
              className={`action-history-page-icon action-history-page-icon--${tone}`}
              aria-hidden="true"
            >
              <Icon size={19} />
            </span>
            <div className="action-history-page-copy">
              <div className="action-history-page-heading">
                <strong>{t(ACTION_LABEL_KEY[item.action])}</strong>
                <time dateTime={new Date(item.completedAt).toISOString()}>
                  {formatClockTime(item.completedAt, locale)}
                </time>
              </div>
              <p>{t(actionHistoryDescriptionKey(item.action, item.finalStatus))}</p>
              <div className="action-history-page-meta">
                <span
                  className={`action-history-page-outcome action-history-page-outcome--${outcomeTone}`}
                >
                  {outcomeTone === 'complete' && <Check size={12} aria-hidden="true" />}
                  {t(outcomeKey)}
                </span>
                <span>{formatRelativeTime(item.completedAt, relativeNow, t)}</span>
                {item.durationMs !== undefined && <span>{formatDuration(item.durationMs, t)}</span>}
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function formatClockTime(timestamp: number, locale: string) {
  return new Intl.DateTimeFormat(locale, {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(timestamp);
}

function formatRelativeTime(timestamp: number, now: number, t: Translate) {
  const seconds = Math.max(0, Math.floor((now - timestamp) / 1000));
  if (seconds < 10) return t('history.justNow');
  if (seconds < 60) return t('history.secondsAgo', { value: seconds });
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return t('history.minutesAgo', { value: minutes });
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return t('history.hoursAgo', { value: hours });
  return t('history.daysAgo', { value: Math.floor(hours / 24) });
}

function formatDuration(durationMs: number, t: Translate) {
  const seconds = Math.round(durationMs / 1000);
  return seconds < 1 ? t('history.underSecond') : t('history.durationSeconds', { value: seconds });
}
