import { useEffect, useRef, useState, type AnimationEvent } from 'react';
import {
  AlertTriangle,
  CircleCheck,
  Globe2,
  KeyRound,
  LoaderCircle,
  Monitor,
  Power,
  Settings2,
  type LucideIcon,
  WandSparkles,
  Wifi,
} from 'lucide-react';
import {
  PcControl,
  type OpenVpnProfile,
  type OpenVpnStatusResult,
  type SshHostKeyResult,
} from '@pc-control/capacitor-pc-control';
import {
  isPowerOnConfigured,
  isPcConnectionConfigured,
  validateAppSettings,
  type AppSettings,
  type PcControlConfig,
  type PcStatus,
} from '@pc-control/core';
import { useAppCopy } from '../i18n';
import { PreferenceRow, PreferenceToolbar, Ripple, useRipple } from './ui/preferences';
import { describeError } from '../lib/errorMapping';
import {
  isPcUnavailableError,
  isSshAuthError,
  type PcVerificationState,
} from '../lib/pcVerification';

type BackHandler = () => boolean;
type Check = 'idle' | 'checking' | 'ok' | 'error';
type RouterLoginCheck = 'idle' | 'checking' | 'pending' | 'ok' | 'auth-failed' | 'error';
type PcCheck = PcVerificationState;
type HostKeyScanState = 'idle' | 'checking' | 'pending' | 'error';
type DiagnosticsPage =
  'overview' | 'connection' | 'wake' | 'remote' | 'quickCheck' | 'pcTrust' | 'routerTrust';
type QuickDiagnosticStatus = 'idle' | 'checking' | 'passed' | 'attention';
type QuickDiagnosticStepId = 'settings' | 'identity' | 'pc' | 'wake' | 'remote';
type QuickDiagnosticStep = {
  id: QuickDiagnosticStepId;
  status: QuickDiagnosticStatus;
};
type NetworkEnsuredHandler = (vpnWasStartedByApp: boolean) => void;

const QUICK_DIAGNOSTIC_STEP_IDS: QuickDiagnosticStepId[] = [
  'settings',
  'identity',
  'pc',
  'wake',
  'remote',
];

const QUICK_DIAGNOSTIC_STEP_ICONS: Record<QuickDiagnosticStepId, LucideIcon> = {
  settings: Settings2,
  identity: KeyRound,
  pc: Monitor,
  wake: Power,
  remote: Globe2,
};

const MIN_QUICK_DIAGNOSTIC_STEP_DURATION_MS = 800;

function createQuickDiagnosticSteps(): QuickDiagnosticStep[] {
  return QUICK_DIAGNOSTIC_STEP_IDS.map((id) => ({ id, status: 'idle' }));
}

export function DiagnosticsScreen({
  settings,
  config,
  onToast,
  closing,
  onBack,
  onTransitionEnd,
  registerBack,
}: {
  settings: AppSettings;
  config: PcControlConfig;
  onToast: (message: string) => void;
  closing: boolean;
  onBack: () => void;
  onTransitionEnd: () => void;
  registerBack: (handler: BackHandler | null) => void;
}) {
  const { t, copy } = useAppCopy();
  const [pcStatus, setPcStatus] = useState<PcStatus>('unknown');
  const [pcCheck, setPcCheck] = useState<PcCheck>('idle');
  const [routerCheck, setRouterCheck] = useState<Check>('idle');
  const [routerLoginCheck, setRouterLoginCheck] = useState<RouterLoginCheck>('idle');
  const [vpnInstalled, setVpnInstalled] = useState<boolean>();
  const [vpnProfiles, setVpnProfiles] = useState<OpenVpnProfile[]>([]);
  const [vpnSelectedProfile, setVpnSelectedProfile] = useState<string>();
  const [vpnPermission, setVpnPermission] = useState<Check>('idle');
  const [vpnStatus, setVpnStatus] = useState<OpenVpnStatusResult>({
    status: 'disconnected',
    vpnWasStartedByApp: false,
  });
  const [quickDiagnosticSteps, setQuickDiagnosticSteps] = useState(createQuickDiagnosticSteps);
  const [quickDiagnosticRunning, setQuickDiagnosticRunning] = useState(false);
  const [quickDiagnosticCleanupFailed, setQuickDiagnosticCleanupFailed] = useState(false);
  const [quickDiagnosticActiveStep, setQuickDiagnosticActiveStep] =
    useState<QuickDiagnosticStepId>();
  const quickDiagnosticRunningRef = useRef(false);
  const [page, setPage] = useState<DiagnosticsPage>('overview');
  const ensureNetwork = config.router.host
    ? () =>
        PcControl.ensureHomeNetwork({
          routerHost: config.router.host,
          routerPort: config.router.sshPort,
          postConnectReachabilityTimeoutMs: 10000,
        })
    : undefined;

  const handlePageAnimationEnd = (event: AnimationEvent<HTMLDivElement>) => {
    if (!closing) return;
    if (event.target !== event.currentTarget) return;
    if (event.animationName !== 'page-transition-exit-down') return;

    onTransitionEnd();
  };

  useEffect(() => {
    registerBack(() => {
      if (page === 'overview') return false;
      setPage(page === 'pcTrust' ? 'connection' : page === 'routerTrust' ? 'wake' : 'overview');
      return true;
    });
    return () => registerBack(null);
  }, [page, registerBack]);
  useEffect(() => {
    void PcControl.isOpenVpnInstalled()
      .then((result) => setVpnInstalled(result.installed))
      .catch(() => setVpnInstalled(false));
    void PcControl.getOpenVpnProfiles()
      .then((result) => {
        setVpnProfiles(result.profiles);
        setVpnSelectedProfile(result.selectedProfileId);
      })
      .catch(() => setVpnProfiles([]));
    void PcControl.getOpenVpnPermissionStatus()
      .then((result) => {
        setVpnInstalled(result.installed);
        setVpnPermission(result.granted ? 'ok' : 'error');
      })
      .catch(() => {
        setVpnPermission('error');
      });
    void PcControl.getOpenVpnStatus()
      .then(setVpnStatus)
      .catch(() => setVpnStatus((current) => ({ ...current, status: 'error' })));
    if (!config.pc.host) return;
    void PcControl.getPcStatus({
      host: config.pc.host,
      port: config.pc.sshPort,
      timeoutMs: 2500,
      ...(config.router.host
        ? { routerHost: config.router.host, routerPort: config.router.sshPort }
        : {}),
    })
      .then((result) => {
        setPcStatus(result.status);
        if (result.status === 'offline' && result.reason !== 'network-unavailable') {
          setPcCheck('offline');
        }
      })
      .catch(() => setPcStatus('unknown'));
  }, [config.pc.host, config.pc.sshPort, config.router.host, config.router.sshPort]);

  async function checkPc(
    notify = true,
    onNetworkEnsured?: NetworkEnsuredHandler,
  ): Promise<QuickDiagnosticStatus> {
    if (!config.pc.host || !config.pc.sshUser || !Number.isInteger(config.pc.sshPort)) {
      return 'attention';
    }
    setPcCheck('checking');
    try {
      if (ensureNetwork) {
        const network = await ensureNetwork();
        onNetworkEnsured?.(network.vpnWasStartedByApp);
      }
      const reachable = await PcControl.checkHost({
        host: config.pc.host,
        port: config.pc.sshPort,
        timeoutMs: 5000,
      });
      if (!reachable.reachable) {
        setPcStatus('offline');
        setPcCheck('offline');
        if (notify) onToast(copy('diagnostics.connection.pcOfflinePending'));
        return 'attention';
      }
      setPcStatus('online');
      const trusted = await PcControl.getTrustedSshHostKey({
        host: config.pc.host,
        port: config.pc.sshPort,
      });
      if (!trusted.trusted || !trusted.fingerprint) {
        setPcCheck('host-key-unverified');
        if (notify) onToast(copy('diagnostics.connection.hostKeyPending'));
        return 'attention';
      }
      try {
        await PcControl.executeSshCommand({
          host: config.pc.host,
          port: config.pc.sshPort,
          target: 'windows',
          username: config.pc.sshUser,
          command: 'hostname',
          expectedHostFingerprint: trusted.fingerprint,
          connectTimeoutMs: 5000,
          commandTimeoutMs: 5000,
        });
      } catch (error) {
        if (isPcUnavailableError(error)) {
          setPcStatus('offline');
          setPcCheck('offline');
          if (notify) onToast(copy('diagnostics.connection.pcOfflinePending'));
          return 'attention';
        }
        if (isSshAuthError(error)) {
          setPcCheck('auth-failed');
          const described = describeError(error);
          if (notify) onToast(copy(described.key, described.params));
          return 'attention';
        }
        throw error;
      }
      setPcCheck('verified');
      if (notify) onToast(copy('diagnostics.connection.success'));
      return 'passed';
    } catch (error) {
      if (isPcUnavailableError(error)) {
        setPcStatus('offline');
        setPcCheck('offline');
        if (notify) onToast(copy('diagnostics.connection.pcOfflinePending'));
      } else {
        setPcCheck('error');
        const described = describeError(error);
        if (notify) onToast(copy(described.key, described.params));
      }
      return 'attention';
    }
  }

  async function checkRouter(
    notify = true,
    onNetworkEnsured?: NetworkEnsuredHandler,
  ): Promise<QuickDiagnosticStatus> {
    if (!config.router.host || !Number.isInteger(config.router.sshPort)) return 'attention';
    setRouterCheck('checking');
    try {
      if (ensureNetwork) {
        const network = await ensureNetwork();
        onNetworkEnsured?.(network.vpnWasStartedByApp);
      } else {
        const result = await PcControl.checkHost({
          host: config.router.host,
          port: config.router.sshPort,
          timeoutMs: 5000,
        });
        if (!result.reachable) throw { code: 'HOST_UNREACHABLE' };
      }
      setRouterCheck('ok');
      if (notify) onToast(copy('diagnostics.wake.routerSuccess'));
      return 'passed';
    } catch (error) {
      setRouterCheck('error');
      const described = describeError(error);
      if (notify) onToast(copy(described.key, described.params));
      return 'attention';
    }
  }

  async function checkRouterLogin(
    notify = true,
    onNetworkEnsured?: NetworkEnsuredHandler,
  ): Promise<QuickDiagnosticStatus> {
    if (!config.router.host || !config.router.sshUser || !Number.isInteger(config.router.sshPort)) {
      return 'attention';
    }
    setRouterLoginCheck('checking');
    try {
      if (ensureNetwork) {
        const network = await ensureNetwork();
        onNetworkEnsured?.(network.vpnWasStartedByApp);
      }
      const trusted = await PcControl.getTrustedSshHostKey({
        host: config.router.host,
        port: config.router.sshPort,
      });
      if (!trusted.trusted || !trusted.fingerprint) {
        setRouterLoginCheck('pending');
        if (notify) onToast(copy('diagnostics.connection.hostKeyPending'));
        return 'attention';
      }
      await PcControl.executeSshCommand({
        host: config.router.host,
        port: config.router.sshPort,
        target: 'router',
        username: config.router.sshUser,
        command: 'uname -a',
        expectedHostFingerprint: trusted.fingerprint,
        connectTimeoutMs: 5000,
        commandTimeoutMs: 5000,
      });
      setRouterLoginCheck('ok');
      if (notify) onToast(copy('diagnostics.wake.routerLoginSuccess'));
      return 'passed';
    } catch (error) {
      if (isPcUnavailableError(error)) {
        setRouterLoginCheck('pending');
      } else if (isSshAuthError(error)) {
        setRouterLoginCheck('auth-failed');
      } else {
        setRouterLoginCheck('error');
      }
      const described = describeError(error);
      if (notify) onToast(copy(described.key, described.params));
      return 'attention';
    }
  }

  function checkSettings(): QuickDiagnosticStatus {
    return isPcConnectionConfigured(settings) &&
      isPowerOnConfigured(settings) &&
      validateAppSettings(settings).length === 0
      ? 'passed'
      : 'attention';
  }

  async function checkIdentity(): Promise<QuickDiagnosticStatus> {
    try {
      const result = await PcControl.getSshIdentity();
      return result.available ? 'passed' : 'attention';
    } catch {
      return 'attention';
    }
  }

  async function checkRemotePrerequisites(): Promise<QuickDiagnosticStatus> {
    try {
      const installation = await PcControl.isOpenVpnInstalled();
      setVpnInstalled(installation.installed);
      if (!installation.installed) {
        setVpnProfiles([]);
        setVpnSelectedProfile(undefined);
        setVpnPermission('error');
        return 'attention';
      }

      const [profiles, permission, status] = await Promise.all([
        PcControl.getOpenVpnProfiles(),
        PcControl.getOpenVpnPermissionStatus(),
        PcControl.getOpenVpnStatus(),
      ]);
      setVpnProfiles(profiles.profiles);
      setVpnSelectedProfile(profiles.selectedProfileId);
      setVpnPermission(permission.granted ? 'ok' : 'error');
      setVpnStatus(status);
      const selectedProfile = profiles.profiles.some(
        (profile) => profile.id === profiles.selectedProfileId,
      );
      const vpnReady = status.status === 'connected' || status.status === 'disconnected';
      return permission.granted && selectedProfile && vpnReady ? 'passed' : 'attention';
    } catch {
      setVpnPermission('error');
      return 'attention';
    }
  }

  async function runQuickDiagnostics() {
    if (quickDiagnosticRunning || quickDiagnosticRunningRef.current) return;
    let nextSteps = createQuickDiagnosticSteps();
    setQuickDiagnosticSteps(nextSteps);
    setQuickDiagnosticCleanupFailed(false);
    quickDiagnosticRunningRef.current = true;
    setQuickDiagnosticRunning(true);
    let vpnStartedByQuickDiagnostic = false;
    const observeNetwork = (vpnWasStartedByApp: boolean) => {
      vpnStartedByQuickDiagnostic ||= vpnWasStartedByApp;
    };

    const runStep = async (
      id: QuickDiagnosticStepId,
      check: () => QuickDiagnosticStatus | Promise<QuickDiagnosticStatus>,
    ) => {
      const stepStartedAt = Date.now();
      setQuickDiagnosticActiveStep(id);
      nextSteps = nextSteps.map((step) =>
        step.id === id ? { ...step, status: 'checking' } : step,
      );
      setQuickDiagnosticSteps(nextSteps);
      let status: QuickDiagnosticStatus;
      try {
        status = await check();
      } catch {
        status = 'attention';
      }
      const remainingDuration =
        MIN_QUICK_DIAGNOSTIC_STEP_DURATION_MS - (Date.now() - stepStartedAt);
      if (remainingDuration > 0) {
        await new Promise<void>((resolve) => {
          window.setTimeout(resolve, remainingDuration);
        });
      }
      nextSteps = nextSteps.map((step) => (step.id === id ? { ...step, status } : step));
      setQuickDiagnosticSteps(nextSteps);
      return status;
    };

    try {
      await runStep('settings', () => checkSettings());
      await runStep('identity', checkIdentity);
      await runStep('pc', () => checkPc(false, observeNetwork));
      await runStep('wake', async () => {
        const routerReachability = await checkRouter(false, observeNetwork);
        if (routerReachability !== 'passed') return routerReachability;
        return checkRouterLogin(false, observeNetwork);
      });
      await runStep('remote', checkRemotePrerequisites);
    } finally {
      let cleanupFailed = false;
      if (vpnStartedByQuickDiagnostic) {
        try {
          const result = await PcControl.disconnectOpenVpn({
            onlyIfStartedByApp: true,
            timeoutMs: 10000,
          });
          setVpnStatus(result);
          cleanupFailed = result.status === 'error';
        } catch {
          setVpnStatus((current) => ({ ...current, status: 'error' }));
          cleanupFailed = true;
        }
      }
      quickDiagnosticRunningRef.current = false;
      setQuickDiagnosticCleanupFailed(cleanupFailed);
      setQuickDiagnosticActiveStep(undefined);
      setQuickDiagnosticRunning(false);
    }
  }

  if (page === 'overview') {
    return (
      <div
        className={`diagnostics-overview diagnostics-screen-page preferences-page ${
          closing ? 'page-transition-exit' : 'page-transition-enter'
        }`}
        onAnimationEnd={handlePageAnimationEnd}
      >
        <PreferenceToolbar
          title={t('diagnostics.title')}
          backLabel={t('navigation.back')}
          onBack={onBack}
        />
        <div className="preferences-list">
          <div className="preferences-group">
            <PreferenceRow
              icon="connections"
              title={copy('diagnostics.overview.connectionTitle')}
              summary={copy('diagnostics.overview.connectionDescription')}
              disabled={quickDiagnosticRunning}
              onClick={() => setPage('connection')}
            />
            <PreferenceRow
              icon="multi-devices"
              title={copy('diagnostics.overview.wakeTitle')}
              summary={copy('diagnostics.overview.wakeDescription')}
              disabled={quickDiagnosticRunning}
              onClick={() => setPage('wake')}
            />
            <PreferenceRow
              icon="security"
              title={copy('diagnostics.overview.remoteTitle')}
              summary={copy('diagnostics.overview.remoteDescription')}
              disabled={quickDiagnosticRunning}
              onClick={() => setPage('remote')}
            />
            <PreferenceRow
              icon="modes"
              title={copy('diagnostics.quickCheck.title')}
              summary={copy('diagnostics.quickCheck.description')}
              onClick={() => setPage('quickCheck')}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`diagnostics-detail-page diagnostics-screen-page preferences-page ${
        closing ? 'page-transition-exit' : 'page-transition-enter'
      }`}
      data-diagnostics-page={page}
      onAnimationEnd={handlePageAnimationEnd}
    >
      <PreferenceToolbar
        title={
          page === 'quickCheck'
            ? copy('diagnostics.quickCheck.title')
            : copy(`diagnostics.${page}.title`)
        }
        backLabel={t('navigation.backToDiagnostics')}
        onBack={() =>
          setPage(page === 'pcTrust' ? 'connection' : page === 'routerTrust' ? 'wake' : 'overview')
        }
      />
      {page === 'connection' && (
        <>
          <section className="diagnostics-section">
            <StatusRow
              label={t('diagnostics.connection.pcStatus')}
              description={t('diagnostics.connection.pcStatusDescription')}
              value={statusLabel(pcStatus, t)}
              tone={pcStatus === 'online' ? 'ok' : pcStatus === 'offline' ? 'muted' : 'warn'}
            />
          </section>
          <section className="diagnostics-section">
            <DiagnosticActionRow
              label={copy('diagnostics.connection.loginTitle')}
              description={copy('diagnostics.connection.loginDescription')}
              value={
                pcCheck === 'checking'
                  ? t('common.checking')
                  : pcCheck === 'verified'
                    ? t('common.ok')
                    : pcCheck === 'offline'
                      ? t('common.verificationPending')
                      : pcCheck === 'host-key-unverified'
                        ? t('diagnostics.connection.hostKeyPendingStatus')
                        : pcCheck === 'auth-failed'
                          ? copy('diagnostics.connection.authFailedStatus')
                          : pcCheck === 'error'
                            ? t('common.needsAttention')
                            : t('common.beforeCheck')
              }
              tone={
                pcCheck === 'verified'
                  ? 'ok'
                  : pcCheck === 'error' || pcCheck === 'auth-failed'
                    ? 'error'
                    : 'warn'
              }
              disabled={quickDiagnosticRunning || !config.pc.host || pcCheck === 'checking'}
              onClick={() => void checkPc()}
            />
            <HostKeyRow
              variant="summary"
              host={config.pc.host}
              port={config.pc.sshPort}
              kind="pc"
              {...(ensureNetwork ? { ensureNetwork } : {})}
              disabled={quickDiagnosticRunning}
              onOpenPage={() => setPage('pcTrust')}
              onToast={onToast}
            />
          </section>
        </>
      )}

      {page === 'wake' && (
        <>
          <section className="diagnostics-section">
            <DiagnosticActionRow
              label={t('diagnostics.wake.routerReachability')}
              description={config.router.host || t('diagnostics.wake.routerAddress')}
              value={checkLabel(routerCheck, t)}
              tone={checkTone(routerCheck)}
              disabled={quickDiagnosticRunning || !config.router.host || routerCheck === 'checking'}
              onClick={() => void checkRouter()}
            />
            <DiagnosticActionRow
              label={t('diagnostics.wake.routerLogin')}
              description={copy('diagnostics.wake.routerLoginDescription')}
              value={routerLoginLabel(routerLoginCheck, t, copy)}
              tone={routerLoginTone(routerLoginCheck)}
              disabled={
                quickDiagnosticRunning ||
                !config.router.host ||
                !config.router.sshUser ||
                routerLoginCheck === 'checking'
              }
              onClick={() => void checkRouterLogin()}
            />
          </section>
          <section className="diagnostics-section">
            <HostKeyRow
              variant="summary"
              host={config.router.host}
              port={config.router.sshPort}
              kind="router"
              {...(ensureNetwork ? { ensureNetwork } : {})}
              disabled={quickDiagnosticRunning}
              onOpenPage={() => setPage('routerTrust')}
              onToast={onToast}
            />
          </section>
        </>
      )}

      {page === 'pcTrust' && (
        <HostKeyRow
          variant="page"
          host={config.pc.host}
          port={config.pc.sshPort}
          kind="pc"
          {...(ensureNetwork ? { ensureNetwork } : {})}
          onToast={onToast}
        />
      )}

      {page === 'routerTrust' && (
        <HostKeyRow
          variant="page"
          host={config.router.host}
          port={config.router.sshPort}
          kind="router"
          {...(ensureNetwork ? { ensureNetwork } : {})}
          onToast={onToast}
        />
      )}

      {page === 'remote' && (
        <section className="diagnostics-section">
          <StatusRow
            label={t('diagnostics.remote.app')}
            description={t('diagnostics.remote.appDescription')}
            value={
              vpnInstalled === undefined
                ? t('common.checking')
                : vpnInstalled
                  ? t('diagnostics.remote.install')
                  : t('diagnostics.remote.installRequired')
            }
            tone={vpnInstalled ? 'ok' : vpnInstalled === false ? 'warn' : 'muted'}
          />
          <StatusRow
            label={t('diagnostics.remote.profile')}
            description={t('diagnostics.remote.profileDescription')}
            value={
              vpnInstalled === false
                ? t('common.notAvailable')
                : (vpnProfiles.find((profile) => profile.id === vpnSelectedProfile)?.name ??
                  t('common.notSelected'))
            }
            tone={vpnSelectedProfile ? 'ok' : 'warn'}
          />
          <StatusRow
            label={t('diagnostics.remote.permission')}
            description={t('diagnostics.remote.permissionDescription')}
            value={vpnInstalled === false ? t('common.notAvailable') : checkLabel(vpnPermission, t)}
            tone={vpnInstalled === false ? 'muted' : checkTone(vpnPermission)}
          />
          <StatusRow
            label={t('diagnostics.remote.vpnStatus')}
            description={t('diagnostics.remote.vpnStatusDescription')}
            value={vpnStatusLabel(vpnStatus.status, t)}
            tone={vpnStatusTone(vpnStatus.status)}
          />
        </section>
      )}

      {page === 'quickCheck' && (
        <QuickDiagnosticsCard
          steps={quickDiagnosticSteps}
          running={quickDiagnosticRunning}
          cleanupFailed={quickDiagnosticCleanupFailed}
          {...(quickDiagnosticActiveStep ? { activeStep: quickDiagnosticActiveStep } : {})}
          onRun={() => void runQuickDiagnostics()}
        />
      )}
    </div>
  );
}

function QuickDiagnosticsCard({
  steps,
  running,
  activeStep,
  cleanupFailed,
  onRun,
}: {
  steps: QuickDiagnosticStep[];
  running: boolean;
  activeStep?: QuickDiagnosticStepId;
  cleanupFailed: boolean;
  onRun: () => void;
}) {
  const { copy } = useAppCopy();
  const hasResults = steps.some((step) => step.status !== 'idle');
  const passed = steps.filter((step) => step.status === 'passed').length;
  const attentionCount =
    steps.filter((step) => step.status === 'attention').length + (cleanupFailed ? 1 : 0);
  const total = steps.length;
  const heroState = running
    ? 'running'
    : !hasResults
      ? 'ready'
      : attentionCount > 0
        ? 'attention'
        : 'passed';
  const heroTitle = copy(
    `diagnostics.quickCheck.hero.${heroState}`,
    heroState === 'attention' ? { count: attentionCount } : undefined,
  );
  const heroDetail = running
    ? copy('diagnostics.quickCheck.hero.progress', {
        step: activeStep
          ? copy(`diagnostics.quickCheck.steps.${activeStep}`)
          : copy('diagnostics.quickCheck.running'),
      })
    : heroState === 'ready'
      ? copy('diagnostics.quickCheck.hero.planned', { total })
      : heroState === 'passed'
        ? copy('diagnostics.quickCheck.success', { passed, total })
        : copy('diagnostics.quickCheck.hero.attention', { count: attentionCount });
  return (
    <section
      className={`diagnostics-quick-check-card diagnostics-quick-check-state-${heroState}`}
      aria-label={copy('diagnostics.quickCheck.title')}
    >
      <div className="diagnostics-quick-check-hero" role="status" aria-live="polite">
        <div className="diagnostics-quick-check-orbit" aria-hidden="true">
          <span className="diagnostics-quick-check-orbit-ring diagnostics-quick-check-orbit-ring-outer" />
          <span className="diagnostics-quick-check-orbit-ring diagnostics-quick-check-orbit-ring-inner" />
          <span className="diagnostics-quick-check-orbit-core">
            {heroState === 'running' ? (
              <LoaderCircle className="diagnostics-quick-check-loading-icon" size={38} />
            ) : heroState === 'passed' ? (
              <CircleCheck size={38} />
            ) : heroState === 'attention' ? (
              <AlertTriangle size={38} />
            ) : (
              <WandSparkles size={38} />
            )}
          </span>
        </div>
        <h2 className="diagnostics-quick-check-hero-title">{heroTitle}</h2>
        <p className="diagnostics-quick-check-hero-detail">{heroDetail}</p>
      </div>
      <button
        type="button"
        className="diagnostics-quick-check-button"
        disabled={running}
        onClick={onRun}
      >
        {running
          ? copy('diagnostics.quickCheck.running')
          : hasResults
            ? copy('diagnostics.quickCheck.rerun')
            : copy('diagnostics.quickCheck.run')}
      </button>
      <div className="diagnostics-quick-check-panel">
        <ul
          className="diagnostics-quick-check-list"
          aria-label={copy('diagnostics.quickCheck.items')}
        >
          {steps.map((step) => {
            const StepIcon = QUICK_DIAGNOSTIC_STEP_ICONS[step.id];
            const stepLabel = copy(`diagnostics.quickCheck.steps.${step.id}`);
            const stepStatusLabel = copy(`diagnostics.quickCheck.status.${step.status}`);
            return (
              <li
                className={`diagnostics-quick-check-row diagnostics-quick-check-row-${step.status}`}
                key={step.id}
                aria-label={`${stepLabel}: ${stepStatusLabel}`}
              >
                <span className="diagnostics-quick-check-step-icon">
                  <StepIcon size={20} strokeWidth={2.1} aria-hidden="true" />
                </span>
                <span className="diagnostics-quick-check-step-label">{stepLabel}</span>
                {step.status !== 'idle' && (
                  <span
                    className={`diagnostics-quick-check-status ${quickDiagnosticToneClass(
                      step.status,
                    )}`}
                    role="img"
                    aria-label={stepStatusLabel}
                  >
                    <QuickDiagnosticStatusIcon status={step.status} />
                  </span>
                )}
              </li>
            );
          })}
          {cleanupFailed && (
            <li className="diagnostics-quick-check-row diagnostics-quick-check-row-attention">
              <span className="diagnostics-quick-check-step-icon">
                <Wifi size={20} strokeWidth={2.1} aria-hidden="true" />
              </span>
              <span className="diagnostics-quick-check-step-label">
                {copy('diagnostics.quickCheck.steps.cleanup')}
              </span>
              <span
                className="diagnostics-quick-check-status status-warning"
                role="img"
                aria-label={copy('diagnostics.quickCheck.status.attention')}
              >
                <QuickDiagnosticStatusIcon status="attention" />
              </span>
            </li>
          )}
        </ul>
      </div>
    </section>
  );
}

function QuickDiagnosticStatusIcon({ status }: { status: Exclude<QuickDiagnosticStatus, 'idle'> }) {
  const Icon =
    status === 'passed' ? CircleCheck : status === 'attention' ? AlertTriangle : LoaderCircle;
  return (
    <Icon
      className={`diagnostics-quick-check-status-icon ${quickDiagnosticToneClass(status)} ${
        status === 'checking' ? 'diagnostics-quick-check-status-icon-checking' : ''
      }`}
      size={18}
      strokeWidth={2.4}
      aria-hidden="true"
    />
  );
}

function quickDiagnosticToneClass(status: QuickDiagnosticStatus) {
  return status === 'passed'
    ? 'status-success'
    : status === 'attention'
      ? 'status-warning'
      : status === 'checking'
        ? 'status-primary'
        : 'text-muted';
}

function StatusRow({
  label,
  description,
  value,
  tone,
}: {
  label: string;
  description?: string | undefined;
  value: string;
  tone: 'ok' | 'warn' | 'error' | 'muted';
}) {
  return (
    <div className="diagnostics-status-row">
      <div className="diagnostics-status-layout">
        <div className="diagnostics-row-copy">
          <p className="diagnostics-row-label">{label}</p>
          {description && <p className="diagnostics-row-description">{description}</p>}
        </div>
        <p className={`diagnostics-row-value ${diagnosticsToneClass(tone)}`}>{value}</p>
      </div>
    </div>
  );
}

function DiagnosticActionRow({
  label,
  description,
  value,
  tone,
  disabled = false,
  onClick,
}: {
  label: string;
  description: string;
  value: string;
  tone: 'ok' | 'warn' | 'error' | 'muted';
  disabled?: boolean;
  onClick: () => void;
}) {
  const { ripple, handlePointerDown, releaseRipple, clearRipple } = useRipple();

  return (
    <button
      type="button"
      className="diagnostics-action-row"
      disabled={disabled}
      onClick={onClick}
      onPointerDown={disabled ? undefined : handlePointerDown}
      onPointerUp={releaseRipple}
      onPointerCancel={releaseRipple}
    >
      <Ripple ripple={ripple} onReleaseEnd={clearRipple} />
      <span className="diagnostics-action-copy">
        <b>{label}</b>
        <small>{description}</small>
      </span>
      <span className={`diagnostics-action-value ${diagnosticsToneClass(tone)}`}>{value}</span>
    </button>
  );
}

function diagnosticsToneClass(tone: 'ok' | 'warn' | 'error' | 'muted') {
  return tone === 'ok'
    ? 'status-success'
    : tone === 'error'
      ? 'status-danger'
      : tone === 'warn'
        ? 'status-warning'
        : 'text-muted';
}

function checkLabel(check: Check, t: (key: string) => string) {
  return check === 'checking'
    ? t('common.checking')
    : check === 'ok'
      ? t('common.ok')
      : check === 'error'
        ? t('common.needsAttention')
        : t('common.beforeCheck');
}

function checkTone(check: Check): 'ok' | 'warn' | 'error' | 'muted' {
  return check === 'ok' ? 'ok' : check === 'error' ? 'error' : check === 'idle' ? 'warn' : 'warn';
}

function routerLoginLabel(
  check: RouterLoginCheck,
  t: (key: string) => string,
  copy: (key: string) => string,
) {
  return check === 'checking'
    ? t('common.checking')
    : check === 'ok'
      ? t('common.ok')
      : check === 'auth-failed'
        ? copy('diagnostics.connection.authFailedStatus')
        : check === 'pending'
          ? t('common.verificationPending')
          : check === 'error'
            ? t('common.needsAttention')
            : t('common.beforeCheck');
}

function routerLoginTone(check: RouterLoginCheck): 'ok' | 'warn' | 'error' | 'muted' {
  return check === 'ok' ? 'ok' : check === 'auth-failed' || check === 'error' ? 'error' : 'warn';
}

function statusLabel(status: PcStatus, t: (key: string) => string) {
  return status === 'online'
    ? t('common.online')
    : status === 'offline'
      ? t('common.verificationPending')
      : status === 'error'
        ? t('common.error')
        : status === 'waking'
          ? t('home.statusWaking')
          : status === 'shutting-down'
            ? t('home.statusShuttingDown')
            : status === 'rebooting'
              ? t('home.statusRebooting')
              : t('common.beforeCheck');
}

function vpnStatusLabel(status: OpenVpnStatusResult['status'], t: (key: string) => string) {
  return status === 'connected'
    ? t('common.connected')
    : status === 'connecting'
      ? t('common.connecting')
      : status === 'disconnecting'
        ? t('common.disconnecting')
        : status === 'error'
          ? t('common.needsAttention')
          : t('common.disconnected');
}

function vpnStatusTone(status: OpenVpnStatusResult['status']): 'ok' | 'warn' | 'error' | 'muted' {
  return status === 'connected'
    ? 'ok'
    : status === 'error'
      ? 'error'
      : status === 'disconnected'
        ? 'muted'
        : 'warn';
}

function HostKeyRow({
  variant,
  host,
  port,
  kind,
  disabled = false,
  ensureNetwork,
  onOpenPage,
  onToast,
}: {
  variant: 'summary' | 'page';
  host: string;
  port: number;
  kind: 'pc' | 'router';
  disabled?: boolean;
  ensureNetwork?: () => Promise<unknown>;
  onOpenPage?: () => void;
  onToast: (message: string) => void;
}) {
  const { t, copy } = useAppCopy();
  const [key, setKey] = useState<{
    algorithm?: string;
    fingerprint?: string;
    trusted: boolean;
  }>();
  const keyRef = useRef<typeof key>(undefined);
  useEffect(() => {
    keyRef.current = key;
  }, [key]);
  const [busy, setBusy] = useState(false);
  const [scanState, setScanState] = useState<HostKeyScanState>('idle');
  useEffect(() => {
    if (!host) return;
    void PcControl.getTrustedSshHostKey({ host, port })
      .then(setKey)
      .catch(() => setKey({ trusted: false }));
  }, [host, port]);

  async function scan(): Promise<SshHostKeyResult | undefined> {
    setBusy(true);
    setScanState('checking');
    try {
      if (ensureNetwork) await ensureNetwork();
      if (kind === 'pc') {
        const reachable = await PcControl.checkHost({ host, port, timeoutMs: 5000 });
        if (!reachable.reachable) {
          setScanState('pending');
          onToast(copy('diagnostics.connection.pcOfflinePending'));
          return undefined;
        }
      }
      const previousFingerprint = keyRef.current?.fingerprint;
      const result = await PcControl.scanSshHostKey({ host, port, connectTimeoutMs: 5000 });
      setKey(result);
      setScanState('idle');
      if (previousFingerprint) {
        onToast(
          copy(
            previousFingerprint === result.fingerprint
              ? 'diagnostics.security.securityInfoRefreshUnchanged'
              : 'diagnostics.security.securityInfoRefreshChanged',
          ),
        );
      }
      return result;
    } catch (error) {
      if (kind === 'pc' && isPcUnavailableError(error)) {
        setScanState('pending');
        onToast(copy('diagnostics.connection.pcOfflinePending'));
      } else {
        setScanState('error');
        const described = describeError(error);
        onToast(copy(described.key, described.params));
      }
      return undefined;
    } finally {
      setBusy(false);
    }
  }

  async function trust() {
    if (!key?.algorithm || !key.fingerprint) return;
    setBusy(true);
    try {
      setKey(
        await PcControl.trustSshHostKey({
          host,
          port,
          algorithm: key.algorithm,
          fingerprint: key.fingerprint,
        }),
      );
      setScanState('idle');
    } catch (error) {
      setScanState('error');
      const described = describeError(error);
      onToast(copy(described.key, described.params));
    } finally {
      setBusy(false);
    }
  }
  const trustLabel =
    kind === 'pc'
      ? copy('diagnostics.security.hostTrust')
      : copy('diagnostics.security.routerTrust');
  const trustDescription =
    kind === 'pc'
      ? copy('diagnostics.security.pcTrustDescription')
      : copy('diagnostics.security.routerTrustDescription');
  const statusRow = (
    <StatusRow
      label={t('diagnostics.security.currentStatus')}
      description={trustDescription}
      value={
        !host
          ? t('diagnostics.security.addressRequired')
          : key?.trusted
            ? t('diagnostics.security.verified')
            : scanState === 'pending' && kind === 'pc'
              ? t('common.verificationPending')
              : scanState === 'error'
                ? t('common.needsAttention')
                : key?.fingerprint
                  ? t('diagnostics.security.reviewRequired')
                  : t('common.beforeCheck')
      }
      tone={key?.trusted ? 'ok' : scanState === 'error' ? 'error' : 'warn'}
    />
  );

  if (variant === 'summary') {
    return (
      <DiagnosticActionRow
        label={trustLabel}
        description={
          key?.fingerprint
            ? t('diagnostics.security.viewFingerprint')
            : t('diagnostics.security.scanDescription')
        }
        value={
          !host
            ? t('diagnostics.security.addressRequired')
            : key?.trusted
              ? t('diagnostics.security.verified')
              : key?.fingerprint
                ? t('diagnostics.security.reviewRequired')
                : t('common.beforeCheck')
        }
        tone={key?.trusted ? 'ok' : 'warn'}
        disabled={disabled || !host}
        onClick={() => onOpenPage?.()}
      />
    );
  }

  return (
    <div className="diagnostics-host-key-page">
      <div className="diagnostics-host-key-target">
        <p className="diagnostics-host-key-detail-label">{t('diagnostics.security.target')}</p>
        <p className="diagnostics-host-key-detail-value diagnostics-host-key-target-value">
          {host ? `${host}:${port}` : t('diagnostics.security.addressRequired')}
        </p>
      </div>
      <section className="diagnostics-section">{statusRow}</section>
      {key?.algorithm && key.fingerprint && (
        <section className="diagnostics-host-key-details">
          <div>
            <p className="diagnostics-host-key-detail-label">
              {t('diagnostics.security.algorithm')}
            </p>
            <p className="diagnostics-host-key-detail-value">{key.algorithm}</p>
          </div>
          <div>
            <p className="diagnostics-host-key-detail-label">
              {t('diagnostics.security.serverFingerprint')}
            </p>
            <p className="diagnostics-host-key-detail-value diagnostics-host-key-fingerprint">
              {key.fingerprint}
            </p>
          </div>
        </section>
      )}
      <section className="diagnostics-section">
        <DiagnosticActionRow
          label={key?.fingerprint ? t('common.recheck') : t('common.check')}
          description={t('diagnostics.security.scanDescription')}
          value={
            busy ? t('common.checking') : key?.fingerprint ? t('common.recheck') : t('common.check')
          }
          tone="muted"
          disabled={!host || busy}
          onClick={() => void scan()}
        />
        <DiagnosticActionRow
          label={
            kind === 'pc'
              ? copy('diagnostics.security.trustPc')
              : copy('diagnostics.security.trustRouter')
          }
          description={trustDescription}
          value={
            key?.trusted
              ? t('common.completed')
              : key?.fingerprint
                ? t('diagnostics.security.reviewRequired')
                : t('diagnostics.security.verifyFirst')
          }
          tone={key?.trusted ? 'ok' : 'warn'}
          disabled={busy || !key?.fingerprint || key.trusted}
          onClick={() => void trust()}
        />
      </section>
    </div>
  );
}
