/* eslint-disable react-hooks/set-state-in-effect -- synchronize the draft with persisted settings */
import { useEffect, useRef, useState } from 'react';

import { PcControl, type OpenVpnProfile } from '@pc-control/capacitor-pc-control';
import {
  type AppSettings,
  isPcConnectionConfigured,
  isPowerOnConfigured,
  validateAppSettings,
} from '@pc-control/core';
import { describeError } from '../lib/errorMapping';
import {
  isPcUnavailableError,
  isSshAuthError,
  type PcVerificationState,
} from '../lib/pcVerification';
import { Power } from 'lucide-react';
import { useAppCopy } from '../i18n';
import { Field } from './ui/field';
import { InfoSheet } from './ui/info-sheet';
import { SshIdentityPanel } from './SshIdentityPanel';

type BackHandler = () => boolean;
type ConnectionTestState = PcVerificationState;
type HostTrustState = 'idle' | 'pending' | 'verified' | 'error';
type HostKeyInfo = { algorithm: string; fingerprint: string; trusted: boolean };
type FieldErrors = Partial<Record<keyof AppSettings, string>>;

function toHostKeyInfo(result: {
  algorithm?: string;
  fingerprint?: string;
  trusted: boolean;
}): HostKeyInfo | undefined {
  if (!result.algorithm || !result.fingerprint) return undefined;
  return {
    algorithm: result.algorithm,
    fingerprint: result.fingerprint,
    trusted: result.trusted,
  };
}

const STEP_KEYS = [
  'onboarding.steps.welcome',
  'onboarding.steps.pc',
  'onboarding.steps.identity',
  'onboarding.steps.power',
  'onboarding.steps.remote',
  'onboarding.steps.test',
] as const;

export function OnboardingScreen({
  settings,
  onSave,
  onComplete,
  onSkip,
  registerBack,
  onToast,
}: {
  settings: AppSettings;
  onSave: (next: AppSettings) => Promise<void>;
  onComplete: () => void;
  onSkip: () => void;
  registerBack: (handler: BackHandler | null) => void;
  onToast: (message: string) => void;
}) {
  const { t, copy } = useAppCopy();
  const steps = STEP_KEYS.map((key) => t(key));
  const [step, setStep] = useState(
    Math.min(Math.max(settings.onboardingStep, 0), STEP_KEYS.length - 1),
  );
  const [draft, setDraft] = useState(settings);
  const [identity, setIdentity] = useState<{
    available: boolean;
    fingerprint?: string;
    publicKey?: string;
  }>();
  const [identityBusy, setIdentityBusy] = useState(false);
  const [vpnInstalled, setVpnInstalled] = useState<boolean>();
  const [vpnProfiles, setVpnProfiles] = useState<OpenVpnProfile[]>([]);
  const [vpnSelectedProfile, setVpnSelectedProfile] = useState<string>();
  const [vpnProfilesBusy, setVpnProfilesBusy] = useState(false);
  const [hostKey, setHostKey] = useState<{
    algorithm: string;
    fingerprint: string;
    trusted: boolean;
  }>();
  const [hostKeyBusy, setHostKeyBusy] = useState(false);
  const [routerHostKey, setRouterHostKey] = useState<{
    algorithm: string;
    fingerprint: string;
    trusted: boolean;
  }>();
  const [routerHostKeyBusy, setRouterHostKeyBusy] = useState(false);
  const [help, setHelp] = useState<string | null>(null);
  const [showSkipDialog, setShowSkipDialog] = useState(false);
  const [testState, setTestState] = useState<ConnectionTestState>('idle');
  const [showValidation, setShowValidation] = useState(false);
  const [wakeBusy, setWakeBusy] = useState(false);
  const [showPcAdvanced, setShowPcAdvanced] = useState(false);
  const [showWakeAdvanced, setShowWakeAdvanced] = useState(false);
  const [routerTrustState, setRouterTrustState] = useState<HostTrustState>('idle');
  const [trustSheet, setTrustSheet] = useState<'pc' | 'router' | null>(null);
  const quickSetupReentryRef = useRef(
    settings.onboardingCompleted || isPcConnectionConfigured(settings),
  );

  useEffect(() => setDraft(settings), [settings]);
  useEffect(() => {
    setHostKey(undefined);
    setTestState('idle');
  }, [draft.pcHost, draft.pcPort]);
  useEffect(() => {
    setRouterHostKey(undefined);
    setRouterTrustState('idle');
  }, [draft.routerHost, draft.routerPort]);
  useEffect(() => {
    registerBack(() => {
      if (showSkipDialog) {
        setShowSkipDialog(false);
        return true;
      }
      if (help) {
        setHelp(null);
        return true;
      }
      if (trustSheet) {
        setTrustSheet(null);
        return true;
      }
      if (step > 0) {
        setStep((current) => current - 1);
        return true;
      }
      return false;
    });
    return () => registerBack(null);
  }, [help, registerBack, showSkipDialog, step, trustSheet]);

  useEffect(() => {
    if (step !== 2) return;
    void PcControl.getSshIdentity()
      .then(setIdentity)
      .catch(() => setIdentity({ available: false }));
  }, [step]);

  useEffect(() => {
    if (step !== 4) return;
    void PcControl.isOpenVpnInstalled()
      .then((result) => setVpnInstalled(result.installed))
      .catch(() => setVpnInstalled(false));
  }, [step]);

  async function loadVpnProfiles() {
    setVpnProfilesBusy(true);
    try {
      const result = await PcControl.getOpenVpnProfiles();
      setVpnProfiles(result.profiles);
      setVpnSelectedProfile(result.selectedProfileId);
      setVpnInstalled(true);
    } catch (error) {
      setVpnInstalled(false);
      const described = describeError(error);
      onToast(copy(described.key, described.params));
    } finally {
      setVpnProfilesBusy(false);
    }
  }

  async function selectVpnProfile(profileId: string) {
    try {
      const result = await PcControl.selectOpenVpnProfile({ profileId });
      setVpnProfiles(result.profiles);
      setVpnSelectedProfile(result.selectedProfileId);
      onToast(t('settings.toast.profileSelected'));
    } catch (error) {
      const described = describeError(error);
      onToast(copy(described.key, described.params));
    }
  }

  function update<K extends keyof AppSettings>(key: K, value: AppSettings[K]) {
    setDraft((current) => ({ ...current, [key]: value, onboardingCompleted: false }));
  }

  const validationErrors: FieldErrors = {};
  if (showValidation) {
    for (const error of validateAppSettings(draft)) {
      validationErrors[error.field] = t(error.key);
    }
  }

  async function persist(next: AppSettings, commit = !quickSetupReentryRef.current) {
    // A completed user's quick-setup pass is transactional until they finish it.
    if (commit) await onSave(next);
    setDraft(next);
  }

  async function nextStep() {
    const fieldsToValidate: Array<keyof AppSettings> =
      step === 1
        ? ['pcHost', 'pcPort', 'pcUsername']
        : step === 3
          ? ['pcMac', 'routerHost', 'routerPort', 'routerUsername', 'wolInterface']
          : [];
    if (
      fieldsToValidate.length &&
      validateAppSettings(draft).some((error) => fieldsToValidate.includes(error.field))
    ) {
      setShowValidation(true);
      return;
    }
    const next = Math.min(step + 1, STEP_KEYS.length - 1);
    await persist({ ...draft, onboardingStep: next, onboardingCompleted: false });
    setStep(next);
    setShowValidation(false);
  }

  async function finish() {
    if (!isPcConnectionConfigured(draft)) {
      setShowValidation(true);
      return;
    }
    await persist({ ...draft, onboardingStep: 0, onboardingCompleted: true }, true);
    onComplete();
    onToast(
      testState === 'verified' && (!isPowerOnConfigured(draft) || routerTrustState === 'verified')
        ? t('onboarding.setupComplete')
        : copy('onboarding.setupCompletePending'),
    );
  }

  async function ensureIdentity() {
    setIdentityBusy(true);
    try {
      const result = await PcControl.ensureSshIdentity();
      setIdentity(result);
      onToast(t('onboarding.identityReady'));
    } catch {
      onToast(t('onboarding.identityFailed'));
    } finally {
      setIdentityBusy(false);
    }
  }

  async function copyKey() {
    try {
      await PcControl.copySshPublicKey();
      onToast(t('onboarding.publicKeyCopied'));
    } catch {
      onToast(t('onboarding.publicKeyCopyFailed'));
    }
  }

  async function runConnectionTest() {
    setTestState('checking');
    try {
      if (!(await checkPcReachabilityForVerification())) return;
      const trusted = hostKey?.trusted
        ? hostKey
        : await PcControl.getTrustedSshHostKey({ host: draft.pcHost, port: draft.pcPort });
      setHostKey(toHostKeyInfo(trusted));
      if (!trusted.trusted || !trusted.fingerprint) {
        setTestState('host-key-unverified');
        onToast(copy('onboarding.hostKeyVerificationPending'));
        return;
      }
      const sshRequest = {
        host: draft.pcHost,
        port: draft.pcPort,
        target: 'windows',
        username: draft.pcUsername,
        command: 'hostname',
        connectTimeoutMs: 20000,
        commandTimeoutMs: 5000,
        expectedHostFingerprint: trusted.fingerprint,
      } as const;
      try {
        await PcControl.executeSshCommand(sshRequest);
      } catch (error) {
        if (isPcUnavailableError(error)) {
          setTestState('offline');
          onToast(copy('onboarding.pcOfflineVerificationPending'));
          return;
        }
        if (isSshAuthError(error)) {
          setTestState('auth-failed');
          const described = describeError(error);
          onToast(copy(described.key, described.params));
          return;
        }
        throw error;
      }
      if (isPowerOnConfigured(draft)) {
        const trustedRouter = routerHostKey?.trusted
          ? routerHostKey
          : await PcControl.getTrustedSshHostKey({
              host: draft.routerHost,
              port: draft.routerPort,
            });
        setRouterHostKey(toHostKeyInfo(trustedRouter));
        setTestState('verified');
        if (!trustedRouter.trusted || !trustedRouter.fingerprint) {
          setRouterTrustState('pending');
          onToast(copy('errors.routerHostKeyUnknown'));
          return;
        }
        setRouterTrustState('verified');
      }
      setTestState('verified');
    } catch (error) {
      if (isPcUnavailableError(error)) {
        setTestState('offline');
        onToast(copy('onboarding.pcOfflineVerificationPending'));
      } else {
        setTestState('error');
        const described = describeError(error);
        onToast(copy(described.key, described.params));
      }
    }
  }

  async function ensureTestNetwork() {
    if (!draft.routerHost) return;
    await PcControl.ensureHomeNetwork({
      routerHost: draft.routerHost,
      routerPort: draft.routerPort,
      postConnectReachabilityTimeoutMs: 10000,
    });
  }

  async function checkPcReachabilityForVerification() {
    await ensureTestNetwork();
    const reachability = await PcControl.checkHost({
      host: draft.pcHost,
      port: draft.pcPort,
      timeoutMs: 5000,
    });
    if (!reachability.reachable) {
      setTestState('offline');
      onToast(copy('onboarding.pcOfflineVerificationPending'));
      return false;
    }
    return true;
  }

  async function wakePc() {
    if (!isPowerOnConfigured(draft) || wakeBusy) return;
    setWakeBusy(true);
    try {
      const trustedRouter = routerHostKey?.trusted
        ? routerHostKey
        : await PcControl.getTrustedSshHostKey({
            host: draft.routerHost,
            port: draft.routerPort,
          });
      if (!trustedRouter.trusted || !trustedRouter.fingerprint) {
        setRouterTrustState('pending');
        onToast(copy('errors.routerHostKeyUnknown'));
        return;
      }
      await PcControl.runPowerAction({
        action: 'power-on',
        autoDisconnectVpn: draft.autoDisconnectVpn,
        macAddress: draft.pcMac,
        pcHost: draft.pcHost,
        pcPort: draft.pcPort,
        pcUsername: draft.pcUsername,
        routerHost: draft.routerHost,
        routerPort: draft.routerPort,
        routerUsername: draft.routerUsername,
        wolInterface: draft.wolInterface,
        routerHostFingerprint: trustedRouter.fingerprint,
        connectTimeoutMs: 20000,
        postConnectReachabilityTimeoutMs: 10000,
      });
      await runConnectionTest();
    } catch (error) {
      if (isPcUnavailableError(error)) {
        setTestState('offline');
        onToast(copy('onboarding.pcOfflineVerificationPending'));
      } else {
        setTestState('error');
        const described = describeError(error);
        onToast(copy(described.key, described.params));
      }
    } finally {
      setWakeBusy(false);
    }
  }

  async function scanHostKey() {
    setHostKeyBusy(true);
    try {
      if (!(await checkPcReachabilityForVerification())) return;
      const result = await PcControl.scanSshHostKey({
        host: draft.pcHost,
        port: draft.pcPort,
        connectTimeoutMs: 5000,
      });
      setHostKey(result);
      if (result.trusted) {
        await runConnectionTest();
      } else {
        setTestState('host-key-unverified');
        onToast(t('onboarding.comparePcFingerprint'));
      }
    } catch (error) {
      if (isPcUnavailableError(error)) {
        setTestState('offline');
        onToast(copy('onboarding.pcOfflineVerificationPending'));
      } else {
        setTestState('error');
        const described = describeError(error);
        onToast(copy(described.key, described.params));
      }
    } finally {
      setHostKeyBusy(false);
    }
  }

  async function trustHostKey() {
    if (!hostKey) return;
    setHostKeyBusy(true);
    try {
      const result = await PcControl.trustSshHostKey({
        host: draft.pcHost,
        port: draft.pcPort,
        algorithm: hostKey.algorithm,
        fingerprint: hostKey.fingerprint,
      });
      setHostKey(result);
      onToast(t('onboarding.pcTrusted'));
      await runConnectionTest();
    } catch (error) {
      setTestState('error');
      const described = describeError(error);
      onToast(copy(described.key, described.params));
    } finally {
      setHostKeyBusy(false);
    }
  }

  async function scanRouterHostKey() {
    setRouterHostKeyBusy(true);
    try {
      await ensureTestNetwork();
      const result = await PcControl.scanSshHostKey({
        host: draft.routerHost,
        port: draft.routerPort,
        connectTimeoutMs: 5000,
      });
      setRouterHostKey(result);
      setRouterTrustState(result.trusted ? 'verified' : 'pending');
      onToast(
        result.trusted ? t('onboarding.routerTrusted') : t('onboarding.compareRouterFingerprint'),
      );
    } catch (error) {
      setRouterTrustState('error');
      const described = describeError(error);
      onToast(copy(described.key, described.params));
    } finally {
      setRouterHostKeyBusy(false);
    }
  }

  async function trustRouterHostKey() {
    if (!routerHostKey) return;
    setRouterHostKeyBusy(true);
    try {
      const result = await PcControl.trustSshHostKey({
        host: draft.routerHost,
        port: draft.routerPort,
        algorithm: routerHostKey.algorithm,
        fingerprint: routerHostKey.fingerprint,
      });
      setRouterHostKey(result);
      setRouterTrustState('verified');
      onToast(t('onboarding.routerTrusted'));
      await runConnectionTest();
    } catch (error) {
      setRouterTrustState('error');
      const described = describeError(error);
      onToast(copy(described.key, described.params));
    } finally {
      setRouterHostKeyBusy(false);
    }
  }

  const progress = t('onboarding.header.progress', {
    current: step + 1,
    total: steps.length,
  });

  return (
    <div className="mx-auto max-w-xl px-5 pb-10 pt-8">
      <header className="flex items-center justify-between">
        <div className="brand-lockup" aria-label={t('onboarding.header.brandLabel')}>
          <span className="brand-icon">
            <Power size={20} aria-hidden="true" />
          </span>
          <span>PC Control</span>
        </div>
        <button
          type="button"
          className="quiet-button px-0!"
          onClick={() => setShowSkipDialog(true)}
        >
          {t('onboarding.header.skip')}
        </button>
      </header>

      <div className="mt-8 flex items-center justify-between text-xs text-muted">
        <span>{steps[step]}</span>
        <span>{progress}</span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-(--app-surface-muted)">
        <div
          className="h-full rounded-full bg-(--app-primary) transition-all"
          style={{ width: `${((step + 1) / STEP_KEYS.length) * 100}%` }}
        />
      </div>

      <section className="mt-8">
        {step === 0 && <Welcome />}
        {step === 1 && (
          <PcSetup
            draft={draft}
            update={update}
            errors={validationErrors}
            showAdvanced={showPcAdvanced}
            onToggleAdvanced={() => setShowPcAdvanced((value) => !value)}
            onHelp={() => setHelp(t('onboarding.pc.help'))}
          />
        )}
        {step === 2 && (
          <KeySetup
            identity={identity}
            busy={identityBusy}
            onEnsure={() => {
              void ensureIdentity();
            }}
            onCopy={() => {
              void copyKey();
            }}
            onHelp={() => setHelp(t('onboarding.key.help'))}
          />
        )}
        {step === 3 && (
          <WakeSetup
            draft={draft}
            update={update}
            errors={validationErrors}
            showAdvanced={showWakeAdvanced}
            onToggleAdvanced={() => setShowWakeAdvanced((value) => !value)}
            onHelp={() => setHelp(t('onboarding.wake.help'))}
          />
        )}
        {step === 4 && (
          <RemoteSetup
            installed={vpnInstalled}
            profiles={vpnProfiles}
            selectedProfileId={vpnSelectedProfile}
            busy={vpnProfilesBusy}
            onRefresh={() => void loadVpnProfiles()}
            onSelect={(profileId) => void selectVpnProfile(profileId)}
          />
        )}
        {step === 5 && (
          <ConnectionTest
            state={testState}
            onTest={() => void runConnectionTest()}
            wakeBusy={wakeBusy}
            onWake={() => void wakePc()}
            onOpenPowerDetails={() => setHelp(t('onboarding.connection.powerOnDescription'))}
            hostKey={hostKey}
            hostKeyBusy={hostKeyBusy}
            onScan={() => void scanHostKey()}
            onOpenHostKeyDetails={() => setTrustSheet('pc')}
            showRouter={Boolean(
              draft.pcMac || draft.routerHost || draft.routerUsername || draft.wolInterface,
            )}
            routerTrustState={routerTrustState}
            routerHostKey={routerHostKey}
            routerHostKeyBusy={routerHostKeyBusy}
            onScanRouter={() => void scanRouterHostKey()}
            onOpenRouterHostKeyDetails={() => setTrustSheet('router')}
          />
        )}
      </section>

      <div className="mt-8 flex gap-3">
        {step > 0 && (
          <button
            type="button"
            className="secondary-button flex-1"
            onClick={() => setStep((current) => current - 1)}
          >
            {t('onboarding.navigation.previous')}
          </button>
        )}
        {step < STEP_KEYS.length - 1 ? (
          <button type="button" className="primary-button flex-1" onClick={() => void nextStep()}>
            {t('onboarding.navigation.continue')}
          </button>
        ) : (
          <button
            type="button"
            className="primary-button flex-1"
            disabled={!isPcConnectionConfigured(draft) || testState === 'checking' || wakeBusy}
            onClick={() => void finish()}
          >
            {t('onboarding.navigation.finish')}
          </button>
        )}
      </div>

      {help && (
        <div className="dialog-backdrop" role="presentation" onClick={() => setHelp(null)}>
          <div
            className="dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="help-title"
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="help-title" className="text-lg font-semibold">
              {t('onboarding.dialog.helpTitle')}
            </h2>
            <p className="mt-3 text-sm leading-6 text-muted">{help}</p>
            <button
              type="button"
              className="primary-button mt-5 w-full"
              onClick={() => setHelp(null)}
            >
              {t('onboarding.dialog.close')}
            </button>
          </div>
        </div>
      )}

      {showSkipDialog && (
        <div
          className="dialog-backdrop"
          role="presentation"
          onClick={() => setShowSkipDialog(false)}
        >
          <div
            className="dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="skip-setup-title"
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="skip-setup-title" className="text-lg font-semibold">
              {t('onboarding.dialog.skipTitle')}
            </h2>
            <p className="mt-3 text-sm leading-6 text-muted">
              {t('onboarding.dialog.skipDescription')}
            </p>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                className="secondary-button flex-1"
                onClick={() => setShowSkipDialog(false)}
              >
                {t('onboarding.dialog.continueSetup')}
              </button>
              <button
                type="button"
                className="primary-button flex-1"
                onClick={() => {
                  setShowSkipDialog(false);
                  onSkip();
                }}
              >
                {t('onboarding.dialog.skip')}
              </button>
            </div>
          </div>
        </div>
      )}

      {trustSheet === 'pc' && hostKey && (
        <HostKeyInfoSheet
          title={copy('diagnostics.security.hostTrust')}
          description={copy('diagnostics.security.pcTrustDescription')}
          target={`${draft.pcHost}:${draft.pcPort}`}
          keyInfo={hostKey}
          trustLabel={copy('diagnostics.security.trustPc')}
          busy={hostKeyBusy}
          onClose={() => setTrustSheet(null)}
          onTrust={() => {
            setTrustSheet(null);
            void trustHostKey();
          }}
        />
      )}
      {trustSheet === 'router' && routerHostKey && (
        <HostKeyInfoSheet
          title={copy('diagnostics.security.routerTrust')}
          description={copy('diagnostics.security.routerTrustDescription')}
          target={`${draft.routerHost}:${draft.routerPort}`}
          keyInfo={routerHostKey}
          trustLabel={copy('diagnostics.security.trustRouter')}
          busy={routerHostKeyBusy}
          onClose={() => setTrustSheet(null)}
          onTrust={() => {
            setTrustSheet(null);
            void trustRouterHostKey();
          }}
        />
      )}
    </div>
  );
}

function Welcome() {
  const { t } = useAppCopy();
  return (
    <div>
      <p className="text-sm font-semibold text-primary">{t('onboarding.welcome.eyebrow')}</p>
      <h1 className="mt-3 text-3xl font-bold tracking-tight">{t('onboarding.welcome.title')}</h1>
      <p className="mt-4 text-base leading-7 text-muted">{t('onboarding.welcome.description')}</p>
      <div className="surface mt-8 p-5">
        <p className="text-sm font-semibold">{t('onboarding.welcome.prepareTitle')}</p>
        <p className="mt-2 text-sm leading-6 text-muted">
          {t('onboarding.welcome.prepareDescription')}
        </p>
      </div>
    </div>
  );
}

function PcSetup({
  draft,
  update,
  errors,
  showAdvanced,
  onToggleAdvanced,
  onHelp,
}: {
  draft: AppSettings;
  update: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  errors: FieldErrors;
  showAdvanced: boolean;
  onToggleAdvanced: () => void;
  onHelp: () => void;
}) {
  const { t, copy } = useAppCopy();
  return (
    <div>
      <h1 className="text-2xl font-bold">{t('onboarding.pc.title')}</h1>
      <p className="mt-2 text-sm leading-6 text-muted">{t('onboarding.pc.description')}</p>
      <div className="mt-6 space-y-4">
        <Field
          label={t('settings.pc.host')}
          value={draft.pcHost}
          helper={t('onboarding.pc.hostHint')}
          error={errors.pcHost}
          reserveSupportingSpace
          onChange={(event) => update('pcHost', event.target.value)}
          placeholder={t('settings.pc.hostPlaceholder')}
          autoCapitalize="none"
          spellCheck={false}
        />
        <Field
          label={copy('settings.pc.username')}
          value={draft.pcUsername}
          error={errors.pcUsername}
          reserveSupportingSpace
          onChange={(event) => update('pcUsername', event.target.value)}
          placeholder={t('settings.pc.usernamePlaceholder')}
          autoCapitalize="none"
        />
      </div>
      <OnboardingDisclosure
        expanded={showAdvanced || Boolean(errors.pcPort)}
        onClick={onToggleAdvanced}
        label={t('settings.more')}
      />
      {(showAdvanced || Boolean(errors.pcPort)) && (
        <div className="mt-2">
          <Field
            label={t('settings.pc.port')}
            value={String(draft.pcPort)}
            error={errors.pcPort}
            helper={t('settings.editHelp.pcPort')}
            reserveSupportingSpace
            type="number"
            onChange={(event) => update('pcPort', Number(event.target.value) || 0)}
          />
        </div>
      )}
      <button type="button" className="quiet-button mt-5 px-0 text-left underline" onClick={onHelp}>
        {t('onboarding.pc.helpLabel')}
      </button>
    </div>
  );
}

function KeySetup({
  identity,
  busy,
  onEnsure,
  onCopy,
  onHelp,
}: {
  identity: { available: boolean; fingerprint?: string; publicKey?: string } | undefined;
  busy: boolean;
  onEnsure: () => void;
  onCopy: () => void;
  onHelp: () => void;
}) {
  const { t } = useAppCopy();
  return (
    <div>
      <h1 className="text-2xl font-bold">{t('onboarding.key.title')}</h1>
      <p className="mt-2 text-sm leading-6 text-muted">{t('onboarding.key.description')}</p>
      <SshIdentityPanel
        identity={identity}
        busy={busy}
        mode="onboarding"
        onEnsure={onEnsure}
        onCopy={onCopy}
      />
      <div className="surface-muted mt-6 p-4 text-sm leading-6 text-muted">
        {t('onboarding.key.scriptHelp')}
      </div>
      <button type="button" className="quiet-button mt-4 px-0 text-left underline" onClick={onHelp}>
        {t('onboarding.key.helpLabel')}
      </button>
    </div>
  );
}

function WakeSetup({
  draft,
  update,
  errors,
  showAdvanced,
  onToggleAdvanced,
  onHelp,
}: {
  draft: AppSettings;
  update: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  errors: FieldErrors;
  showAdvanced: boolean;
  onToggleAdvanced: () => void;
  onHelp: () => void;
}) {
  const { t, copy } = useAppCopy();
  return (
    <div>
      <h1 className="text-2xl font-bold">{t('onboarding.wake.title')}</h1>
      <p className="mt-2 text-sm leading-6 text-muted">{t('onboarding.wake.description')}</p>
      <p className="mt-5 text-sm leading-6 text-muted">
        {t('onboarding.wake.optionalDescription')}
      </p>
      <div className="mt-6 space-y-4">
        <Field
          label={copy('settings.power.mac')}
          value={draft.pcMac}
          error={errors.pcMac}
          reserveSupportingSpace
          onChange={(event) => update('pcMac', event.target.value.toUpperCase())}
          placeholder={t('settings.power.macPlaceholder')}
          autoCapitalize="characters"
          spellCheck={false}
          mono
        />
        <Field
          label={t('settings.power.routerHost')}
          value={draft.routerHost}
          error={errors.routerHost}
          reserveSupportingSpace
          onChange={(event) => update('routerHost', event.target.value)}
          placeholder={t('settings.pc.hostPlaceholder')}
          autoCapitalize="none"
          spellCheck={false}
        />
        <Field
          label={copy('settings.power.routerUsername')}
          value={draft.routerUsername}
          error={errors.routerUsername}
          reserveSupportingSpace
          onChange={(event) => update('routerUsername', event.target.value)}
          placeholder={t('settings.power.routerUsernamePlaceholder')}
          autoCapitalize="none"
        />
        <Field
          label={copy('settings.power.interface')}
          value={draft.wolInterface}
          error={errors.wolInterface}
          reserveSupportingSpace
          onChange={(event) => update('wolInterface', event.target.value)}
          placeholder={t('settings.power.interfacePlaceholder')}
          autoCapitalize="none"
          spellCheck={false}
          mono
        />
      </div>
      <OnboardingDisclosure
        expanded={showAdvanced || Boolean(errors.routerPort)}
        onClick={onToggleAdvanced}
        label={t('settings.more')}
      />
      {(showAdvanced || Boolean(errors.routerPort)) && (
        <div className="mt-2">
          <Field
            label={t('settings.power.routerPort')}
            value={String(draft.routerPort)}
            error={errors.routerPort}
            helper={t('settings.editHelp.routerPort')}
            reserveSupportingSpace
            type="number"
            onChange={(event) => update('routerPort', Number(event.target.value) || 0)}
          />
        </div>
      )}
      <button type="button" className="quiet-button mt-5 px-0 text-left underline" onClick={onHelp}>
        {t('onboarding.wake.helpLabel')}
      </button>
    </div>
  );
}

function RemoteSetup({
  installed,
  profiles,
  selectedProfileId,
  busy,
  onRefresh,
  onSelect,
}: {
  installed: boolean | undefined;
  profiles: OpenVpnProfile[];
  selectedProfileId: string | undefined;
  busy: boolean;
  onRefresh: () => void;
  onSelect: (profileId: string) => void;
}) {
  const { t } = useAppCopy();
  return (
    <div>
      <h1 className="text-2xl font-bold">{t('onboarding.remote.title')}</h1>
      <p className="mt-2 text-sm leading-6 text-muted">{t('onboarding.remote.description')}</p>
      <div className="surface mt-6 p-5">
        <div className="onboarding-status-row">
          <span className="text-sm font-semibold">{t('settings.remote.profile')}</span>
          <span
            className={`onboarding-status-value ${installed === false ? 'status-warning' : selectedProfileId ? 'status-success' : 'text-muted'}`}
          >
            {installed === false
              ? t('settings.remote.profileRequired')
              : selectedProfileId
                ? t('common.selected')
                : t('common.notSelected')}
          </span>
        </div>
        <button
          type="button"
          className="secondary-button mt-4 w-full"
          disabled={busy}
          onClick={onRefresh}
        >
          {busy ? t('common.checking') : t('settings.remote.refresh')}
        </button>
        {profiles.length > 0 && (
          <div
            className="settings-selection-page settings-group mt-3"
            role="radiogroup"
            aria-label={t('settings.remote.profile')}
          >
            {profiles.map((profile) => (
              <button
                key={profile.id}
                type="button"
                className="settings-selection-row"
                role="radio"
                aria-checked={profile.id === selectedProfileId}
                onClick={() => onSelect(profile.id)}
              >
                <span
                  className={`settings-radio ${profile.id === selectedProfileId ? 'settings-radio-selected' : ''}`}
                  aria-hidden="true"
                />
                <span>{profile.name}</span>
              </button>
            ))}
          </div>
        )}
        <p className="mt-4 text-xs leading-5 text-muted">{t('onboarding.remote.install')}</p>
      </div>
    </div>
  );
}

function OnboardingDisclosure({
  expanded,
  onClick,
  label,
}: {
  expanded: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      className="settings-disclosure-button onboarding-disclosure"
      aria-expanded={expanded}
      onClick={onClick}
    >
      {label}
      <span aria-hidden="true">{expanded ? '−' : '+'}</span>
    </button>
  );
}

function ConnectionTest({
  state,
  onTest,
  wakeBusy,
  onWake,
  onOpenPowerDetails,
  hostKey,
  hostKeyBusy,
  onScan,
  onOpenHostKeyDetails,
  showRouter,
  routerTrustState,
  routerHostKey,
  routerHostKeyBusy,
  onScanRouter,
  onOpenRouterHostKeyDetails,
}: {
  state: ConnectionTestState;
  onTest: () => void;
  wakeBusy: boolean;
  onWake: () => void;
  onOpenPowerDetails: () => void;
  hostKey?: HostKeyInfo | undefined;
  hostKeyBusy: boolean;
  onScan: () => void;
  onOpenHostKeyDetails: () => void;
  showRouter: boolean;
  routerTrustState: HostTrustState;
  routerHostKey?: HostKeyInfo | undefined;
  routerHostKeyBusy: boolean;
  onScanRouter: () => void;
  onOpenRouterHostKeyDetails: () => void;
}) {
  const { t, copy } = useAppCopy();
  const isSuccess = state === 'verified';
  const isDanger = state === 'error' || state === 'auth-failed';
  const isPending = state === 'offline' || state === 'host-key-unverified';
  const stateLabel =
    state === 'checking'
      ? t('common.checking')
      : state === 'offline'
        ? t('common.verificationPending')
        : state === 'host-key-unverified'
          ? t('common.verificationPending')
          : state === 'auth-failed'
            ? t('common.needsAttention')
            : state === 'error'
              ? t('common.needsAttention')
              : state === 'verified'
                ? t('common.completed')
                : t('common.beforeCheck');
  return (
    <div>
      <h1 className="text-2xl font-bold">{copy('diagnostics.connection.title')}</h1>
      <p className="mt-2 text-sm leading-6 text-muted">{t('onboarding.connection.description')}</p>
      <div className="surface mt-6 p-5">
        <div className="onboarding-status-row">
          <div className="flex min-w-0 items-center gap-3">
            <span
              className={`h-3 w-3 shrink-0 rounded-full ${isSuccess ? 'bg-(--app-success)' : isDanger ? 'bg-(--app-danger)' : isPending ? 'bg-(--app-warning)' : 'bg-(--app-border)'}`}
            />
            <span className="text-sm font-semibold">{t('onboarding.connection.pcSsh')}</span>
          </div>
          <span
            className={`onboarding-status-value ${isDanger ? 'status-danger' : isSuccess ? 'status-success' : isPending ? 'status-warning' : 'text-muted'}`}
          >
            {stateLabel}
          </span>
        </div>
        <button
          type="button"
          className="secondary-button mt-5 w-full"
          disabled={state === 'checking' || wakeBusy}
          onClick={onTest}
        >
          {state === 'checking'
            ? t('onboarding.connection.scanBusy')
            : t('onboarding.connection.test')}
        </button>
      </div>
      {showRouter && (
        <div className="surface-muted mt-4 p-4">
          <div className="onboarding-status-row">
            <span className="text-sm font-semibold">{t('onboarding.connection.powerOnTitle')}</span>
          </div>
          <button
            type="button"
            className="primary-button mt-3 w-full"
            disabled={wakeBusy || state === 'checking'}
            onClick={onWake}
          >
            {wakeBusy ? t('home.statusWaking') : t('onboarding.connection.powerOn')}
          </button>
          <button
            type="button"
            className="quiet-button mt-2 w-full text-xs"
            onClick={onOpenPowerDetails}
          >
            {t('onboarding.connection.powerOnDetails')}
          </button>
        </div>
      )}
      <div className="surface-muted mt-4 p-4">
        <div className="onboarding-status-row">
          <div className="onboarding-status-copy">
            <p className="text-sm font-semibold">{t('onboarding.connection.trustTitle')}</p>
            <p className="mt-1 text-xs leading-5 text-muted">
              {t('onboarding.connection.trustDescription')}
            </p>
          </div>
          <span
            className={`onboarding-status-value ${hostKey?.trusted ? 'status-success' : hostKey ? 'status-warning' : 'text-muted'}`}
          >
            {hostKey?.trusted
              ? t('common.completed')
              : hostKey
                ? t('common.needsAttention')
                : t('common.beforeCheck')}
          </span>
        </div>
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            className="secondary-button flex-1"
            disabled={hostKeyBusy}
            onClick={onScan}
          >
            {hostKeyBusy ? t('onboarding.connection.scanBusy') : t('onboarding.connection.scan')}
          </button>
          <button
            type="button"
            className="secondary-button flex-1"
            disabled={!hostKey || hostKeyBusy}
            onClick={onOpenHostKeyDetails}
          >
            {t('onboarding.connection.reviewFingerprint')}
          </button>
        </div>
      </div>
      {showRouter && (
        <ServerTrust
          title={copy('diagnostics.security.routerTrust')}
          description={copy('diagnostics.security.routerTrustDescription')}
          keyInfo={routerHostKey}
          verificationState={routerTrustState}
          busy={routerHostKeyBusy}
          onScan={onScanRouter}
          onOpenDetails={onOpenRouterHostKeyDetails}
        />
      )}
    </div>
  );
}

function ServerTrust({
  title,
  description,
  keyInfo,
  verificationState,
  busy,
  onScan,
  onOpenDetails,
}: {
  title: string;
  description: string;
  keyInfo?: HostKeyInfo | undefined;
  verificationState?: HostTrustState;
  busy: boolean;
  onScan: () => void;
  onOpenDetails: () => void;
}) {
  const { t } = useAppCopy();
  const resolvedState = verificationState ?? 'idle';
  const stateLabel =
    resolvedState === 'verified'
      ? t('common.completed')
      : resolvedState === 'pending'
        ? t('common.verificationPending')
        : resolvedState === 'error'
          ? t('common.needsAttention')
          : t('common.beforeCheck');
  return (
    <div className="surface-muted mt-4 p-4">
      <div className="onboarding-status-row">
        <div className="onboarding-status-copy">
          <p className="text-sm font-semibold">{title}</p>
          <p className="mt-1 text-xs leading-5 text-muted">{description}</p>
        </div>
        <span
          className={`onboarding-status-value ${resolvedState === 'verified' ? 'status-success' : resolvedState === 'error' ? 'status-danger' : resolvedState === 'pending' ? 'status-warning' : 'text-muted'}`}
        >
          {stateLabel}
        </span>
      </div>
      <div className="mt-3 flex gap-2">
        <button type="button" className="secondary-button flex-1" disabled={busy} onClick={onScan}>
          {busy ? t('onboarding.connection.scanBusy') : t('onboarding.connection.scan')}
        </button>
        <button
          type="button"
          className="secondary-button flex-1"
          disabled={!keyInfo || busy}
          onClick={onOpenDetails}
        >
          {t('onboarding.connection.reviewFingerprint')}
        </button>
      </div>
    </div>
  );
}

function HostKeyInfoSheet({
  title,
  description,
  target,
  keyInfo,
  trustLabel,
  busy,
  onClose,
  onTrust,
}: {
  title: string;
  description: string;
  target: string;
  keyInfo: HostKeyInfo;
  trustLabel: string;
  busy: boolean;
  onClose: () => void;
  onTrust: () => void;
}) {
  const { t } = useAppCopy();
  return (
    <InfoSheet title={title} description={description} onClose={onClose}>
      <dl className="info-sheet-details">
        <div>
          <dt>{t('diagnostics.security.target')}</dt>
          <dd className="font-mono">{target}</dd>
        </div>
        <div>
          <dt>{t('diagnostics.security.algorithm')}</dt>
          <dd>{keyInfo.algorithm}</dd>
        </div>
        <div>
          <dt>{t('diagnostics.security.serverFingerprint')}</dt>
          <dd className="font-mono">{keyInfo.fingerprint}</dd>
        </div>
      </dl>
      <div className="dialog-actions">
        <button type="button" className="secondary-button flex-1" onClick={onClose}>
          {t('common.close')}
        </button>
        {!keyInfo.trusted && (
          <button type="button" className="primary-button flex-1" disabled={busy} onClick={onTrust}>
            {trustLabel}
          </button>
        )}
      </div>
    </InfoSheet>
  );
}
