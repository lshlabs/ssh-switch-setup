import type { SettingsIconName } from './SettingsIcons';

export type SettingItem = {
  title: string;
  summary: string;
  icon: SettingsIconName;
};

export const primaryItems: SettingItem[] = [
  { title: 'PC 연결', summary: '주소 · 계정', icon: 'multi-devices' },
  { title: 'PC 켜기', summary: 'MAC · 공유기', icon: 'modes' },
  { title: '원격 연결', summary: 'OpenVPN 프로필', icon: 'connections' },
  { title: '앱 설정', summary: '테마 · 언어 · 표시', icon: 'display' },
];

export const secondaryItems: SettingItem[] = [
  { title: '연결 키', summary: '이 휴대폰의 SSH 공개키와 지문', icon: 'security' },
  { title: '진단', summary: '연결 상태와 문제 확인', icon: 'tips' },
];

export const colorOptions = [
  { label: 'Aqua', value: '#00FFFF' },
  { label: 'Azure', value: '#F0FFFF' },
  { label: 'Beige', value: '#F5F5DC' },
] as const;

export type ColorValue = (typeof colorOptions)[number]['value'];

export const defaultSettings = {
  text: 'Default text',
  color: colorOptions[1].value,
};
