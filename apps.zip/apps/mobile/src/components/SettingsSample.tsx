import './SettingsSample.css';

import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type PointerEvent,
  type ReactNode,
} from 'react';

import { settingsIcons, type SettingsIconName } from './SettingsIcons';
import {
  colorOptions,
  defaultSettings,
  primaryItems,
  secondaryItems,
  type ColorValue,
  type SettingItem,
} from './SettingsSample.data';

type RippleState = {
  id: number;
  x: number;
  y: number;
  size: number;
  isReleasing: boolean;
};

function SettingsIcon({ name }: { name: SettingsIconName }) {
  const icon = settingsIcons[name];

  return (
    <svg className="settings-demo-preference-icon" viewBox="0 0 28 28" aria-hidden="true">
      <circle cx="14" cy="14" r="14" fill={icon.color} />
      {icon.paths.map((path) => (
        <path key={path} d={path} fill="#ffffff" />
      ))}
    </svg>
  );
}

function useRipple() {
  const [ripple, setRipple] = useState<RippleState | null>(null);
  const rippleId = useRef(0);

  const handlePointerDown = (event: PointerEvent<HTMLElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    const size =
      2 * Math.hypot(Math.max(x, bounds.width - x), Math.max(y, bounds.height - y));

    setRipple({
      id: rippleId.current++,
      x,
      y,
      size,
      isReleasing: false,
    });

    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const releaseRipple = () => {
    setRipple((current) => (current === null ? null : { ...current, isReleasing: true }));
  };

  const clearRipple = (id: number) => {
    setRipple((current) => (current?.id === id && current.isReleasing ? null : current));
  };

  return { ripple, handlePointerDown, releaseRipple, clearRipple };
}

function Ripple({
  ripple,
  onReleaseEnd,
}: {
  ripple: RippleState | null;
  onReleaseEnd: (id: number) => void;
}) {
  if (ripple === null) {
    return null;
  }

  return (
    <span
      key={ripple.id}
      className={`settings-demo-ripple${ripple.isReleasing ? ' is-releasing' : ''}`}
      style={{
        height: ripple.size,
        left: ripple.x,
        top: ripple.y,
        width: ripple.size,
      }}
      onAnimationEnd={(event) => {
        if (
          event.target === event.currentTarget &&
          event.animationName === 'settings-demo-ripple-release' &&
          ripple.isReleasing
        ) {
          onReleaseEnd(ripple.id);
        }
      }}
      aria-hidden="true"
    />
  );
}

function PreferenceRow({
  title,
  summary,
  icon,
  isLast = false,
}: SettingItem & { isLast?: boolean }) {
  const { ripple, handlePointerDown, releaseRipple, clearRipple } = useRipple();

  return (
    <div
      className="settings-demo-preference-row"
      onPointerCancel={releaseRipple}
      onPointerDown={handlePointerDown}
      onPointerUp={releaseRipple}
    >
      <Ripple ripple={ripple} onReleaseEnd={clearRipple} />

      <div className="settings-demo-preference-icon-frame">
        <SettingsIcon name={icon} />
      </div>

      <div className="settings-demo-preference-copy">
        <div className="settings-demo-preference-title">{title}</div>
        <div className="settings-demo-preference-summary">{summary}</div>
      </div>

      {!isLast && <div className="settings-demo-preference-divider" aria-hidden="true" />}
    </div>
  );
}

function PreferenceGroup({ items }: { items: SettingItem[] }) {
  return (
    <section className="settings-demo-preference-group">
      {items.map((item, index) => (
        <PreferenceRow key={item.title} {...item} isLast={index === items.length - 1} />
      ))}
    </section>
  );
}

function DialogPreferenceRow({
  title,
  summary,
  isLast = false,
  onClick,
}: {
  title: string;
  summary: string;
  isLast?: boolean;
  onClick: () => void;
}) {
  const { ripple, handlePointerDown, releaseRipple, clearRipple } = useRipple();

  return (
    <button
      type="button"
      className={`settings-demo-option-row${isLast ? ' is-last' : ''}`}
      onClick={onClick}
      onPointerCancel={releaseRipple}
      onPointerDown={handlePointerDown}
      onPointerUp={releaseRipple}
    >
      <Ripple ripple={ripple} onReleaseEnd={clearRipple} />

      <span className="settings-demo-option-row-copy">
        <span className="settings-demo-option-row-title">{title}</span>
        <span className="settings-demo-option-row-summary">{summary}</span>
      </span>
    </button>
  );
}

function SwitchPreferenceRow({
  title,
  summary,
  checked,
  isLast = false,
  onToggle,
}: {
  title: string;
  summary: string;
  checked: boolean;
  isLast?: boolean;
  onToggle: () => void;
}) {
  const { ripple, handlePointerDown, releaseRipple, clearRipple } = useRipple();

  return (
    <div
      className={`settings-demo-switch-preference-row${isLast ? ' is-last' : ''}`}
      role="switch"
      tabIndex={0}
      aria-checked={checked}
      onClick={onToggle}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          onToggle();
        }
      }}
      onPointerCancel={releaseRipple}
      onPointerDown={handlePointerDown}
      onPointerUp={releaseRipple}
    >
      <Ripple ripple={ripple} onReleaseEnd={clearRipple} />

      <span className="settings-demo-switch-preference-copy">
        <span className="settings-demo-option-row-title">{title}</span>
        <span className="settings-demo-option-row-summary">{summary}</span>
      </span>

      <span className="settings-demo-switch-preference-control" aria-hidden="true">
        <span className={`settings-demo-switch${checked ? ' is-on' : ''}`}>
          <span className="settings-demo-switch-thumb">
            <span className="settings-demo-switch-highlight" />
            <span className="settings-demo-switch-thumb-fill" />
          </span>
        </span>
      </span>
    </div>
  );
}

type DialogVariant = 'preference-edit' | 'preference-list';

type BackHandler = () => boolean;

type DialogProps = {
  title: string;
  contentClassName?: string;
  dialogClassName?: string;
  isClosing: boolean;
  onClose: () => void;
  onClosed: () => void;
  children: ReactNode;
  actions?: ReactNode;
};

function Dialog({
  title,
  contentClassName = '',
  dialogClassName = '',
  isClosing,
  onClose,
  onClosed,
  children,
  actions,
}: DialogProps) {
  const titleId = useId();

  return (
    <div
      className={`settings-demo-dialog-backdrop${isClosing ? ' is-closing' : ''}`}
      role="presentation"
      onPointerDown={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
    >
      <section
        className={`settings-demo-dialog${dialogClassName.length > 0 ? ` ${dialogClassName}` : ''}${isClosing ? ' is-closing' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onPointerDown={(event) => event.stopPropagation()}
        onAnimationEnd={(event) => {
          if (
            event.target === event.currentTarget &&
            event.animationName === 'settings-demo-dialog-exit-translate' &&
            isClosing
          ) {
            onClosed();
          }
        }}
      >
        <div className="settings-demo-dialog-title-area">
          <h2 id={titleId}>{title}</h2>
        </div>

        <div
          className={`settings-demo-dialog-content${contentClassName.length > 0 ? ` ${contentClassName}` : ''}`}
        >
          {children}
        </div>

        {actions !== undefined && <div className="settings-demo-dialog-actions">{actions}</div>}
      </section>
    </div>
  );
}

export default function SettingsSample({
  onBack,
  registerBack,
}: {
  onBack: () => void;
  registerBack: (handler: BackHandler | null) => void;
}) {
  const [activeDialog, setActiveDialog] = useState<DialogVariant | null>(null);
  const [isDialogClosing, setIsDialogClosing] = useState(false);
  const [textValue, setTextValue] = useState(defaultSettings.text);
  const [textDraft, setTextDraft] = useState(defaultSettings.text);
  const [selectedColor, setSelectedColor] = useState<ColorValue>(defaultSettings.color);
  const [isEnabled, setIsEnabled] = useState(false);
  const textInputRef = useRef<HTMLInputElement>(null);

  const openDialog = (variant: DialogVariant) => {
    if (variant === 'preference-edit') {
      setTextDraft(textValue);
    }
    setIsDialogClosing(false);
    setActiveDialog(variant);
  };

  const closeDialog = useCallback(() => {
    if (activeDialog === null || isDialogClosing) {
      return;
    }

    setIsDialogClosing(true);
  }, [activeDialog, isDialogClosing]);

  const finishClosingDialog = () => {
    setActiveDialog(null);
    setIsDialogClosing(false);
  };

  useEffect(() => {
    if (activeDialog === null || isDialogClosing) {
      return;
    }

    const focusTimer =
      activeDialog === 'preference-edit'
        ? window.setTimeout(() => {
            const input = textInputRef.current;
            input?.focus({ preventScroll: true });
            input?.setSelectionRange(input.value.length, input.value.length);
          }, 0)
        : null;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeDialog();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      if (focusTimer !== null) {
        window.clearTimeout(focusTimer);
      }
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [activeDialog, closeDialog, isDialogClosing]);

  useEffect(() => {
    registerBack(() => {
      if (activeDialog === null) {
        return false;
      }

      closeDialog();
      return true;
    });

    return () => registerBack(null);
  }, [activeDialog, closeDialog, registerBack]);

  return (
    <main className="settings-demo-page">
      <header className="settings-demo-toolbar">
        <button
          type="button"
          className="settings-demo-toolbar-back settings-demo-toolbar-back-button"
          aria-label="뒤로"
          onClick={onBack}
        >
          <svg className="settings-demo-toolbar-back-icon" viewBox="0 0 24 24" aria-hidden="true">
            <path
              d="m15 5-7 7 7 7"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
            />
          </svg>
        </button>
        <h1 className="settings-demo-toolbar-title">설정</h1>
      </header>

      <div className="settings-demo-settings-list">
        <PreferenceGroup items={primaryItems} />

        <div className="settings-demo-category-gap" aria-hidden="true" />

        <PreferenceGroup items={secondaryItems} />

        <div className="settings-demo-category-gap" aria-hidden="true" />

        <section className="settings-demo-option-card" aria-label="설정 예제">
          <DialogPreferenceRow
            title="텍스트 입력"
            summary={textValue}
            onClick={() => openDialog('preference-edit')}
          />
          <DialogPreferenceRow
            title="색상 선택"
            summary={colorOptions.find((option) => option.value === selectedColor)?.label ?? selectedColor}
            onClick={() => openDialog('preference-list')}
          />
          <SwitchPreferenceRow
            title="사용 여부"
            summary={isEnabled ? 'On' : 'Off'}
            checked={isEnabled}
            isLast
            onToggle={() => setIsEnabled((current) => !current)}
          />
        </section>
      </div>

      {activeDialog === 'preference-edit' && (
        <Dialog
          title="텍스트 입력"
          dialogClassName="settings-demo-dialog-preference-edit-dialog"
          contentClassName="settings-demo-dialog-preference-edit-content"
          isClosing={isDialogClosing}
          onClose={closeDialog}
          onClosed={finishClosingDialog}
          actions={
            <>
              <button type="button" className="settings-demo-dialog-action" onClick={closeDialog}>
                취소
              </button>
              <span className="settings-demo-dialog-action-divider" aria-hidden="true" />
              <button
                type="button"
                className="settings-demo-dialog-action"
                onClick={() => {
                  setTextValue(textDraft);
                  closeDialog();
                }}
              >
                확인
              </button>
            </>
          }
        >
          <div className="settings-demo-dialog-preference-edit-scroll">
            <div className="settings-demo-dialog-preference-edit-container">
              <input
                ref={textInputRef}
                className="settings-demo-dialog-input"
                type="text"
                aria-label="텍스트 입력"
                value={textDraft}
                onChange={(event) => setTextDraft(event.target.value)}
              />
            </div>
          </div>
        </Dialog>
      )}

      {activeDialog === 'preference-list' && (
        <Dialog
          title="색상 선택"
          dialogClassName="settings-demo-dialog-preference-list-dialog"
          contentClassName="settings-demo-dialog-preference-list-content"
          isClosing={isDialogClosing}
          onClose={closeDialog}
          onClosed={finishClosingDialog}
          actions={
            <button type="button" className="settings-demo-dialog-action" onClick={closeDialog}>
              취소
            </button>
          }
        >
          <div
            className="settings-demo-dialog-preference-list"
            role="radiogroup"
            aria-label="색상 선택"
          >
            {colorOptions.map((option) => {
              const isSelected = selectedColor === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  className={`settings-demo-dialog-preference-list-row${isSelected ? ' is-selected' : ''}`}
                  role="radio"
                  aria-checked={isSelected}
                  onClick={() => {
                    setSelectedColor(option.value);
                    closeDialog();
                  }}
                >
                  <span className="settings-demo-dialog-preference-list-indicator" aria-hidden="true" />
                  <span>{option.label}</span>
                </button>
              );
            })}
          </div>
        </Dialog>
      )}
    </main>
  );
}
