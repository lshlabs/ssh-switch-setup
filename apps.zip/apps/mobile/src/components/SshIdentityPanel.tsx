import type { SshIdentityResult } from '@pc-control/capacitor-pc-control';
import { useAppCopy } from '../i18n';

export function SshIdentityPanel({
  identity,
  busy,
  mode,
  onEnsure,
  onCopy,
}: {
  identity: SshIdentityResult | undefined;
  busy: boolean;
  mode: 'onboarding' | 'settings';
  onEnsure: () => void;
  onCopy: () => void;
}) {
  const { t } = useAppCopy();
  const key = mode === 'onboarding' ? 'onboarding.key' : 'settings.identity';
  const readyTitle = t(`${key}.${mode === 'onboarding' ? 'readyTitle' : 'ready'}`);
  const fingerprintLabel = t(
    mode === 'onboarding' ? 'diagnostics.security.identityFingerprint' : 'settings.identity.fingerprint',
  );
  const publicKeyLabel = t(
    mode === 'onboarding' ? 'onboarding.key.publicKeyLabel' : 'settings.identity.publicKey',
  );
  const copyLabel = t(`${key}.copy`);

  return identity?.available ? (
    <div className="surface mt-6 p-4 settings-identity-panel">
      <div className="settings-identity-status">
        <span>{mode === 'onboarding' ? readyTitle : t('settings.identity.status')}</span>
        {mode === 'settings' && <strong className="status-success">{readyTitle}</strong>}
      </div>
      <p className="settings-identity-label">{fingerprintLabel}</p>
      <p className="settings-identity-value font-mono">{identity.fingerprint}</p>
      <p className="settings-identity-label">{publicKeyLabel}</p>
      <textarea
        className="field settings-identity-public-key resize-none break-all font-mono text-xs"
        readOnly
        value={identity.publicKey ?? ''}
        aria-label={publicKeyLabel}
      />
      <button type="button" className="secondary-button mt-3 w-full" onClick={onCopy}>
        {copyLabel}
      </button>
    </div>
  ) : (
    <button
      type="button"
      className="primary-button mt-6 w-full"
      disabled={busy}
      onClick={onEnsure}
    >
      {busy
        ? t(`${key}.${mode === 'onboarding' ? 'preparing' : 'preparing'}`)
        : t(`${key}.${mode === 'onboarding' ? 'prepare' : 'prepare'}`)}
    </button>
  );
}
