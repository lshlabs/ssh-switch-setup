import { useEffect, useRef, useState, type Ref } from 'react';
import { Button } from './button';

type ConfirmDialogProps = {
  cancelLabel: string;
  cancelRef?: Ref<HTMLButtonElement>;
  confirmBusyLabel?: string;
  confirmLabel: string;
  confirmVariant?: 'default' | 'destructive' | 'outline' | 'ghost';
  closing?: boolean;
  message?: string;
  onCancel: () => void;
  onConfirm: () => void | Promise<void>;
  placement?: 'center' | 'bottom';
  title: string;
  titleId: string;
};

export function ConfirmDialog({
  cancelLabel,
  cancelRef,
  confirmBusyLabel,
  confirmLabel,
  confirmVariant = 'default',
  closing = false,
  message,
  onCancel,
  onConfirm,
  placement = 'center',
  title,
  titleId,
}: ConfirmDialogProps) {
  const [busy, setBusy] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (closing) return;
    const focusTimer = window.setTimeout(() => {
      dialogRef.current?.querySelector<HTMLButtonElement>('button:not(:disabled)')?.focus();
    }, 0);
    return () => window.clearTimeout(focusTimer);
  }, [closing]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        if (!busy && !closing) {
          event.preventDefault();
          onCancel();
        }
        return;
      }
      if (closing || event.key !== 'Tab') return;

      const dialog = dialogRef.current;
      if (!dialog) return;
      const focusable = Array.from(dialog.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first || !last) return;
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [busy, closing, onCancel]);

  async function confirm() {
    if (busy) return;
    setBusy(true);
    try {
      await onConfirm();
    } finally {
      setBusy(false);
    }
  }

  const descriptionId = `${titleId}-description`;

  return (
    <div
      className={`dialog-backdrop ${placement === 'bottom' ? 'settings-confirm-dialog-backdrop' : ''} ${closing ? 'dialog-backdrop-closing' : ''}`}
      role="presentation"
      onClick={(event) => {
        if (!busy && !closing && event.target === event.currentTarget) onCancel();
      }}
    >
      <div
        ref={dialogRef}
        className={`dialog ${placement === 'bottom' ? 'settings-confirm-dialog' : ''} ${closing ? 'dialog-closing' : ''}`}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={message ? descriptionId : undefined}
        onClick={(event) => event.stopPropagation()}
      >
        <h2 id={titleId}>{title}</h2>
        {message && <p id={descriptionId} className="dialog-message">{message}</p>}
        <div className="dialog-actions">
          <Button
            ref={cancelRef}
            variant="outline"
            className="flex-1"
            disabled={busy || closing}
            onClick={onCancel}
          >
            {cancelLabel}
          </Button>
          <Button
            variant={confirmVariant}
            className="flex-1"
            disabled={busy || closing}
            onClick={() => void confirm()}
          >
            {busy ? (confirmBusyLabel ?? confirmLabel) : confirmLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}
