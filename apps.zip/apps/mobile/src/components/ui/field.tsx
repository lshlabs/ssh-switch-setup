import type { InputHTMLAttributes, ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function Field({
  label,
  helper,
  error,
  mono = false,
  reserveSupportingSpace = false,
  inputClassName,
  ...inputProps
}: Omit<InputHTMLAttributes<HTMLInputElement>, 'className'> & {
  label: ReactNode;
  helper?: ReactNode;
  error?: ReactNode;
  mono?: boolean;
  reserveSupportingSpace?: boolean;
  inputClassName?: string;
}) {
  const supportingText = error ?? helper;
  const hasSupportingText = supportingText !== undefined && supportingText !== null;

  return (
    <label className="field-label">
      {label}
      <input
        {...inputProps}
        className={cn('field mt-2', mono && 'font-mono', inputClassName)}
        aria-invalid={error ? true : undefined}
      />
      {(reserveSupportingSpace || hasSupportingText) && (
        <span
          className={cn('field-supporting', error ? 'field-error' : 'field-helper')}
          aria-live={error ? 'polite' : undefined}
        >
          {supportingText ?? '\u00a0'}
        </span>
      )}
    </label>
  );
}
