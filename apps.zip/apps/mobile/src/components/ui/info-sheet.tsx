import type { ReactNode } from 'react';

export function InfoSheet({
  title,
  description,
  onClose,
  children,
}: {
  title: string;
  description?: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className="dialog-backdrop" role="presentation" onClick={onClose}>
      <div
        className="dialog info-sheet"
        role="dialog"
        aria-modal="true"
        aria-labelledby="info-sheet-title"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 id="info-sheet-title">{title}</h2>
        {description && <p className="dialog-message">{description}</p>}
        {children}
      </div>
    </div>
  );
}
