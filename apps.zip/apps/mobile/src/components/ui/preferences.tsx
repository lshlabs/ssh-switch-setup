import { useRef, useState, type PointerEvent } from 'react';
import { settingsIcons, type SettingsIconName } from '../SettingsIcons';

type RippleState = {
  id: number;
  x: number;
  y: number;
  size: number;
  isReleasing: boolean;
};

export function PreferenceIcon({ name }: { name: SettingsIconName }) {
  const icon = settingsIcons[name];

  return (
    <svg className="preferences-icon" viewBox="0 0 28 28" aria-hidden="true">
      <circle cx="14" cy="14" r="14" fill={icon.color} />
      {icon.paths.map((path) => (
        <path key={path} d={path} fill="#ffffff" />
      ))}
    </svg>
  );
}

export function useRipple() {
  const [ripple, setRipple] = useState<RippleState | null>(null);
  const rippleId = useRef(0);

  const handlePointerDown = (event: PointerEvent<HTMLElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    const size = 2 * Math.hypot(Math.max(x, bounds.width - x), Math.max(y, bounds.height - y));

    setRipple({
      id: rippleId.current++,
      x,
      y,
      size,
      isReleasing: false,
    });

    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const releaseRipple = () => {
    setRipple((current) => (current === null ? null : { ...current, isReleasing: true }));
  };

  const clearRipple = (id: number) => {
    setRipple((current) => (current?.id === id && current.isReleasing ? null : current));
  };

  return { ripple, handlePointerDown, releaseRipple, clearRipple };
}

export function Ripple({
  ripple,
  onReleaseEnd,
}: {
  ripple: RippleState | null;
  onReleaseEnd: (id: number) => void;
}) {
  if (ripple === null) {
    return null;
  }

  return (
    <span
      key={ripple.id}
      className={`preferences-ripple${ripple.isReleasing ? ' is-releasing' : ''}`}
      style={{
        height: ripple.size,
        left: ripple.x,
        top: ripple.y,
        width: ripple.size,
      }}
      onAnimationEnd={(event) => {
        if (
          event.target === event.currentTarget &&
          event.animationName === 'preferences-ripple-release' &&
          ripple.isReleasing
        ) {
          onReleaseEnd(ripple.id);
        }
      }}
      aria-hidden="true"
    />
  );
}

export function PreferenceToolbar({
  title,
  backLabel,
  onBack,
  decorative = false,
}: {
  title: string;
  backLabel: string;
  onBack: () => void;
  decorative?: boolean;
}) {
  return (
    <header className="preferences-toolbar" aria-hidden={decorative || undefined}>
      <button
        type="button"
        className="preferences-toolbar-back preferences-toolbar-back-button"
        aria-label={decorative ? undefined : backLabel}
        tabIndex={decorative ? -1 : undefined}
        onClick={decorative ? undefined : onBack}
      >
        <svg className="preferences-toolbar-back-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path
            d="m15 5-7 7 7 7"
            fill="none"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </svg>
      </button>
      <h1 className="preferences-toolbar-title">{title}</h1>
    </header>
  );
}

export function PreferenceRow({
  detailPage,
  icon,
  title,
  summary,
  onClick,
  tabIndex,
  disabled = false,
}: {
  detailPage?: string;
  icon: SettingsIconName;
  title: string;
  summary: string;
  onClick: () => void;
  tabIndex?: number;
  disabled?: boolean;
}) {
  const { ripple, handlePointerDown, releaseRipple, clearRipple } = useRipple();

  return (
    <button
      type="button"
      className="preferences-row"
      onPointerDown={disabled ? undefined : handlePointerDown}
      onPointerUp={releaseRipple}
      onPointerCancel={releaseRipple}
      data-settings-detail-page={detailPage}
      tabIndex={tabIndex}
      disabled={disabled}
      onClick={onClick}
    >
      <Ripple ripple={ripple} onReleaseEnd={clearRipple} />
      <span className="preferences-icon-frame">
        <PreferenceIcon name={icon} />
      </span>
      <span className="preferences-copy">
        <b className="preferences-title">{title}</b>
        <small className="preferences-summary">{summary}</small>
      </span>
      <span className="preferences-divider" aria-hidden="true" />
    </button>
  );
}
