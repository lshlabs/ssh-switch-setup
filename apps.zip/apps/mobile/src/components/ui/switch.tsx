export function Switch({
  checked,
  onCheckedChange,
  ariaLabel,
  disabled = false,
  interactive = true,
}: {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  ariaLabel: string;
  disabled?: boolean;
  interactive?: boolean;
}) {
  const track = (
    <span className={`app-switch ${checked ? 'app-switch-checked' : ''}`} aria-hidden={!interactive}>
      <span className="app-switch-thumb" aria-hidden="true" />
    </span>
  );

  if (!interactive) return track;

  return (
    <button
      type="button"
      className={`app-switch ${checked ? 'app-switch-checked' : ''}`}
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      onClick={() => onCheckedChange(!checked)}
    >
      <span className="app-switch-thumb" aria-hidden="true" />
    </button>
  );
}
