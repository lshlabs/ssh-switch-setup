import { describe, expect, it } from 'vitest';
import { classifyPcVerificationError } from './pcVerification';

describe('pc verification state classification', () => {
  it('treats SSH socket non-response as offline/pending, not as a setup error', () => {
    expect(classifyPcVerificationError({ code: 'HOST_UNREACHABLE' })).toBe('offline');
    expect(classifyPcVerificationError({ code: 'CONNECTION_TIMEOUT' })).toBe('offline');
  });

  it('keeps SSH authentication failure distinct from reachability', () => {
    expect(classifyPcVerificationError({ code: 'AUTH_FAILED' })).toBe('auth-failed');
  });

  it('keeps security and network configuration failures as errors', () => {
    expect(classifyPcVerificationError({ code: 'HOST_KEY_UNKNOWN' })).toBe('error');
    expect(classifyPcVerificationError({ code: 'HOME_NETWORK_UNAVAILABLE' })).toBe('error');
  });
});
